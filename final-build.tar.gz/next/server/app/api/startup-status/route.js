(()=>{var e={};e.id=2524,e.ids=[326,2524],e.modules={1708:e=>{"use strict";e.exports=require("node:process")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},4573:e=>{"use strict";e.exports=require("node:buffer")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},11723:e=>{"use strict";e.exports=require("querystring")},12412:e=>{"use strict";e.exports=require("assert")},16141:e=>{"use strict";e.exports=require("node:zlib")},19771:e=>{"use strict";e.exports=require("process")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},34982:(e,t,i)=>{"use strict";i.a(e,async(e,r)=>{try{i.r(t),i.d(t,{GET:()=>l,POST:()=>u});var s=i(32190),a=i(80326),n=i(51134),o=i(6710),c=e([a,n,o]);async function l(){try{let e="disconnected";try{let t=await o.A.connect();await t.query("SELECT 1"),t.release(),e="connected"}catch(t){e="error"}let t=n.c.getStatus(),i=a.default.getStatus();return s.NextResponse.json({startup:{initialized:i.initialized,database:e,scheduler:{running:t.isRunning,tasks:t.activeTasks,count:t.tasksCount}},server_time:new Date().toISOString(),environment:"production"})}catch(e){return s.NextResponse.json({error:"Failed to get startup status",details:e instanceof Error?e.message:"Unknown error"},{status:500})}}async function u(){try{console.log("Manual startup initialization requested..."),await a.default.initialize();let e=a.default.getStatus(),t=n.c.getStatus();return s.NextResponse.json({message:"Startup initialization completed",status:{initialized:e.initialized,scheduler_running:t.isRunning,scheduler_tasks:t.tasksCount}})}catch(e){return s.NextResponse.json({error:"Startup initialization failed",details:e instanceof Error?e.message:"Unknown error"},{status:500})}}[a,n,o]=c.then?(await c)():c,r()}catch(e){r(e)}})},37067:e=>{"use strict";e.exports=require("node:http")},37830:e=>{"use strict";e.exports=require("node:stream/web")},42703:e=>{"use strict";e.exports=require("node-cron")},44708:e=>{"use strict";e.exports=require("node:https")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},57075:e=>{"use strict";e.exports=require("node:stream")},57975:e=>{"use strict";e.exports=require("node:util")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64939:e=>{"use strict";e.exports=import("pg")},73024:e=>{"use strict";e.exports=require("node:fs")},73136:e=>{"use strict";e.exports=require("node:url")},73496:e=>{"use strict";e.exports=require("http2")},73566:e=>{"use strict";e.exports=require("worker_threads")},74075:e=>{"use strict";e.exports=require("zlib")},76760:e=>{"use strict";e.exports=require("node:path")},77030:e=>{"use strict";e.exports=require("node:net")},78175:(e,t,i)=>{"use strict";i.a(e,async(e,r)=>{try{i.d(t,{i:()=>u});var s=i(6710),a=i(70664),n=i(74054),o=i(37674),c=e([s,n,o]);[s,n,o]=c.then?(await c)():c;class l{static{this.HIGH_PRIORITY_CHANNELS=[{id:"UCq-Cy3CK3r-qmjM7fXPqTlQ",title:"Good Good"},{id:"UCRvqjQPSeaWn-uEx-w0XOIg",title:"Dude Perfect"},{id:"UCgUueMmSpcl-aCTt5CuCKQw",title:"Grant Horvat Golf"},{id:"UCpzR85N5b5Cil_VE-P0HqWg",title:"Rick Shiels Golf"},{id:"UCGhLVzjASYN8oUxYBtfBfAw",title:"Peter Finch Golf"},{id:"UC5SQGzkWyQSW_fe-URgq7xw",title:"Bryson DeChambeau"},{id:"UCwOImVq9GMSalyC_uS3b-2Q",title:"TaylorMade Golf"},{id:"UCJKDS0Kym93MJSdhFqA8HTg",title:"Mark Crossfield"},{id:"UCm8OIxLBpNJFRbcnXJcXdNw",title:"Golf Sidekick"},{id:"UCbNRBQptR5CL4rX7eI3SWPQ",title:"James Robinson Golf"},{id:"UCqr4sONkmFEOPc3rfoVLEvg",title:"Bob Does Sports"},{id:"UClOp9ASmFYATO1zFfpB7QlA",title:"Eric Cogorno Golf"},{id:"UCokFauAYvXnr3e9TZQFESIQ",title:"Matt Fryer Golf"},{id:"UCJolpQHWLAW6cCUYGgean8w",title:"Padraig Harrington"},{id:"UC_GolfChannelID",title:"Golf Channel"}]}constructor(){this.youtubeClient=new a.Z}async initializeChannels(){let e=await s.A.connect();try{for(let t of(await e.query(`
        CREATE TABLE IF NOT EXISTS monitored_channels (
          id VARCHAR(255) PRIMARY KEY,
          title VARCHAR(255),
          priority VARCHAR(20) DEFAULT 'medium',
          last_checked TIMESTAMP WITH TIME ZONE,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )
      `),l.HIGH_PRIORITY_CHANNELS))await e.query(`
          INSERT INTO monitored_channels (id, title, priority)
          VALUES ($1, $2, $3)
          ON CONFLICT (id) DO UPDATE SET priority = $3
        `,[t.id,t.title,"high"])}finally{e.release()}}async discoverChannelsFromVideos(){let e=await s.A.connect();try{for(let t of(await e.query(`
        SELECT 
          yc.id,
          yc.title,
          COUNT(yv.id) as video_count,
          SUM(yv.view_count) as total_views
        FROM youtube_channels yc
        JOIN youtube_videos yv ON yc.id = yv.channel_id
        WHERE yc.id NOT IN (
          SELECT id FROM monitored_channels
        )
        GROUP BY yc.id, yc.title
        HAVING COUNT(yv.id) >= 2
        ORDER BY SUM(yv.view_count) DESC
        LIMIT 20
      `)).rows)await e.query(`
          INSERT INTO monitored_channels (id, title, priority)
          VALUES ($1, $2, $3)
          ON CONFLICT (id) DO NOTHING
        `,[t.id,t.title,"medium"])}finally{e.release()}}async checkChannelsForNewVideos(e=10){if(!await o.n.canPerformOperation("channel_check"))return console.log("Quota limit reached, skipping channel check"),0;let t=await s.A.connect();try{let i=await t.query(`
        SELECT id, title
        FROM monitored_channels
        WHERE last_checked IS NULL 
           OR last_checked < NOW() - INTERVAL '12 hours'
        ORDER BY 
          CASE priority 
            WHEN 'high' THEN 1 
            WHEN 'medium' THEN 2 
            ELSE 3 
          END,
          last_checked ASC NULLS FIRST
        LIMIT $1
      `,[e]),r=0;for(let e of i.rows)try{console.log(`Checking channel: ${e.title}`);let i=await this.youtubeClient.getChannelVideos(e.id,10);for(let e of(await o.n.recordUsage("channel_check",1),i))await n.T.upsertVideo(e),r++;await t.query(`
            UPDATE monitored_channels 
            SET last_checked = NOW() 
            WHERE id = $1
          `,[e.id])}catch(t){console.error(`Error checking channel ${e.title}:`,t)}return r}finally{t.release()}}async getMonitoredChannels(){let e=await s.A.connect();try{return(await e.query(`
        SELECT id, title, priority, last_checked
        FROM monitored_channels
        ORDER BY 
          CASE priority 
            WHEN 'high' THEN 1 
            WHEN 'medium' THEN 2 
            ELSE 3 
          END,
          title
      `)).rows.map(e=>({id:e.id,title:e.title,priority:e.priority,last_checked:e.last_checked}))}finally{e.release()}}}let u=new l;r()}catch(e){r(e)}})},78312:(e,t,i)=>{"use strict";i.a(e,async(e,r)=>{try{i.r(t),i.d(t,{patchFetch:()=>l,routeModule:()=>u,serverHooks:()=>h,workAsyncStorage:()=>d,workUnitAsyncStorage:()=>p});var s=i(96559),a=i(48088),n=i(37719),o=i(34982),c=e([o]);o=(c.then?(await c)():c)[0];let u=new s.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/startup-status/route",pathname:"/api/startup-status",filename:"route",bundlePath:"app/api/startup-status/route"},resolvedPagePath:"/Users/dbrown/golfllm/frontend/golf-directory/src/app/api/startup-status/route.ts",nextConfigOutput:"standalone",userland:o}),{workAsyncStorage:d,workUnitAsyncStorage:p,serverHooks:h}=u;function l(){return(0,n.patchFetch)({workAsyncStorage:d,workUnitAsyncStorage:p})}r()}catch(e){r(e)}})},78335:()=>{},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},80326:(e,t,i)=>{"use strict";i.a(e,async(e,r)=>{try{i.r(t),i.d(t,{StartupManager:()=>c,default:()=>l});var s=i(51134),a=i(78175),n=i(6710),o=e([s,a,n]);[s,a,n]=o.then?(await o)():o;class c{static{this.initialized=!1}static async initialize(){if(!this.initialized){console.log("\uD83D\uDE80 Starting StreamingRange initialization...");try{await this.checkDatabase(),await this.initializeChannelMonitoring(),await this.ensureSchedulerRunning(),this.initialized=!0,console.log("✅ StreamingRange initialization complete!")}catch(e){throw console.error("❌ Startup initialization failed:",e),e}}}static async checkDatabase(){let e=3;for(;e>0;)try{let e=await n.A.connect();await e.query("SELECT 1"),e.release(),console.log("✅ Database connection verified");return}catch(t){if(e--,console.error(`❌ Database connection failed (${3-e}/3):`,t),0===e)throw t;await new Promise(e=>setTimeout(e,2e3))}}static async initializeChannelMonitoring(){try{await a.i.initializeChannels(),console.log("✅ Channel monitoring initialized")}catch(e){console.error("❌ Channel monitoring initialization failed:",e)}}static async ensureSchedulerRunning(){try{await new Promise(e=>setTimeout(e,6e3));let e=s.c.getStatus();if(e.isRunning)console.log(`✅ Scheduler already running with ${e.tasksCount} tasks`);else{console.log("⚡ Starting scheduler manually..."),s.c.start();let e=s.c.getStatus();e.isRunning?console.log(`✅ Scheduler started with ${e.tasksCount} tasks`):console.error("❌ Failed to start scheduler")}}catch(e){console.error("❌ Scheduler startup failed:",e)}}static getStatus(){return{initialized:this.initialized}}}let l=c;r()}catch(e){r(e)}})},81630:e=>{"use strict";e.exports=require("http")},83997:e=>{"use strict";e.exports=require("tty")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var i=e=>t(t.s=e),r=t.X(0,[4447,580,5976,6402,4054,7355],()=>i(78312));module.exports=r})();
(()=>{var e={};e.id=6852,e.ids=[6852],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},6710:(e,t,r)=>{"use strict";r.a(e,async(e,a)=>{try{r.d(t,{A:()=>o});var n=r(64939),i=e([n]);let o=new(n=(i.then?(await i)():i)[0]).Pool({connectionString:process.env.DATABASE_URL||"postgresql://postgres:mysecretpassword@localhost/postgres",ssl:{rejectUnauthorized:!1},max:10,min:2,idleTimeoutMillis:6e4,connectionTimeoutMillis:5e3,acquireTimeoutMillis:1e4,statement_timeout:3e4,query_timeout:3e4});a()}catch(e){a(e)}})},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},21820:e=>{"use strict";e.exports=require("os")},22160:(e,t,r)=>{"use strict";r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{patchFetch:()=>u,routeModule:()=>c,serverHooks:()=>m,workAsyncStorage:()=>p,workUnitAsyncStorage:()=>d});var n=r(96559),i=r(48088),o=r(37719),s=r(55180),l=e([s]);s=(l.then?(await l)():l)[0];let c=new n.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/generate-transcript-summary/[videoId]/route",pathname:"/api/generate-transcript-summary/[videoId]",filename:"route",bundlePath:"app/api/generate-transcript-summary/[videoId]/route"},resolvedPagePath:"/Users/dbrown/golfllm/frontend/golf-directory/src/app/api/generate-transcript-summary/[videoId]/route.ts",nextConfigOutput:"standalone",userland:s}),{workAsyncStorage:p,workUnitAsyncStorage:d,serverHooks:m}=c;function u(){return(0,o.patchFetch)({workAsyncStorage:p,workUnitAsyncStorage:d})}a()}catch(e){a(e)}})},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55180:(e,t,r)=>{"use strict";r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{GET:()=>m,POST:()=>y});var n=r(32190),i=r(79646),o=r(29021),s=r(33873),l=r.n(s),u=r(21820),c=r.n(u),p=r(6710),d=e([p]);p=(d.then?(await d)():d)[0];let T=new Map;async function m(e,{params:t}){try{let{videoId:e}=await t,r=await _(e);if(r)return n.NextResponse.json({summary:r.summary,audioUrl:r.audioUrl});return n.NextResponse.json({summary:null,audioUrl:null})}catch(e){return console.error("Error checking existing transcript summary:",e),n.NextResponse.json({error:"Failed to check existing summary"},{status:500})}}async function y(e,{params:t}){try{let{videoId:e}=await t,r=T.get(e);if(r&&Date.now()-r.timestamp<864e5)return n.NextResponse.json({summary:r.summary});let a=await _(e);if(a)return T.set(e,{summary:a.summary,timestamp:Date.now()}),n.NextResponse.json({summary:a.summary,audioUrl:a.audioUrl});let i=await g(e);console.log("Generating audio for video:",e);let o=await w(i,e);return console.log("Audio URL generated:",o),await x(e,i,o),T.set(e,{summary:i,timestamp:Date.now()}),n.NextResponse.json({summary:i,audioUrl:o})}catch(e){return console.error("Error generating transcript summary:",e),n.NextResponse.json({error:"Failed to generate summary"},{status:500})}}async function g(e){let t=await o.promises.mkdtemp(l().join(c().tmpdir(),"golf-transcript-"));try{let r=await f(e,t);if(!r)return"No transcript available for this video. The video may not have captions or subtitles.";return await v(r,e)}finally{try{await o.promises.rm(t,{recursive:!0,force:!0})}catch(e){console.error("Error cleaning up temp directory:",e)}}}async function f(e,t){return new Promise((r,a)=>{let n=[`https://youtube.com/watch?v=${e}`,"--skip-download","--write-auto-sub","--write-sub","--sub-langs","en,en-US,en-GB","--sub-format","vtt","--output",l().join(t,"%(id)s.%(ext)s")],s=(0,i.spawn)("yt-dlp",n,{stdio:["ignore","pipe","pipe"]}),u="",c="";s.stdout.on("data",e=>{u+=e.toString()}),s.stderr.on("data",e=>{c+=e.toString()}),s.on("close",async n=>{try{if(0!==n){console.error("yt-dlp failed:",c),r(null);return}for(let a of[l().join(t,`${e}.en.vtt`),l().join(t,`${e}.en-US.vtt`),l().join(t,`${e}.en-GB.vtt`),l().join(t,`${e}.vtt`)])try{let e=await o.promises.readFile(a,"utf-8"),t=function(e){let t=e.split("\n"),r="",a=!1;for(let e of t){let t=e.trim();if("WEBVTT"===t||""===t){a=!1;continue}if(t.includes("--\x3e")){a=!0;continue}if(!t.match(/^NOTE\s/)&&a&&t&&!t.match(/^\d+$/)){let e=t.replace(/<[^>]*>/g,"").replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').trim();e&&(r+=e+" ")}}return r.trim()}(e);if(t)return void r(t)}catch(e){continue}r(null)}catch(e){a(e)}}),s.on("error",e=>{a(e)})})}async function v(e,t){let r=await p.A.connect(),a=null;try{let e=`
      SELECT yv.title, yc.title as channel_name
      FROM youtube_videos yv
      JOIN youtube_channels yc ON yv.channel_id = yc.id
      WHERE yv.id = $1
    `,n=await r.query(e,[t]);n.rows.length>0&&(a=n.rows[0])}finally{r.release()}return await h(e,a)}async function h(e,t){try{let r=process.env.GOOGLE_API_KEY;if(!r)throw Error("GOOGLE_API_KEY not configured");let a=`You are channeling the legendary golf announcer Jim Nantz. Analyze this golf video transcript and create a compelling TRAILER-STYLE preview in Jim's distinctive broadcasting style.

Video Details:
${t?`Title: "${t.title}"`:""}
${t?`Channel: ${t.channel_name}`:""}

Transcript:
${e}

Create a TRAILER-STYLE preview (NOT a full recap) in Jim Nantz's signature style:
- Build anticipation and excitement without revealing outcomes or spoilers
- Focus on what viewers WILL SEE, not what happens
- Tease key moments, players, or situations without giving away results
- Use phrases like "Ladies and gentlemen," "Coming up," "You'll witness," "Hello friends"
- Poetic, measured cadence that creates anticipation
- MAXIMUM 60-75 words (30 seconds of speaking time)
- Think movie trailer energy with Jim's elegant golf sensibility
- End with intrigue that makes people want to watch

Examples of trailer language:
- "Coming up, witness..." 
- "You'll see remarkable..." 
- "Get ready for..." 
- "An unforgettable moment awaits..."

NO SPOILERS. Build excitement for what's TO COME, not what happened.`,n=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${r}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:a}]}],generationConfig:{temperature:.8,topK:40,topP:.95,maxOutputTokens:150}})});if(!n.ok)throw Error(`Gemini API error: ${n.status} ${n.statusText}`);let i=await n.json();if(i.candidates&&i.candidates[0]&&i.candidates[0].content)return i.candidates[0].content.parts[0].text.trim()+"\n\n[AI-generated from video transcript]";throw Error("Unexpected response format from Gemini API")}catch(e){var r,a;return console.error("Error generating Gemini summary:",e),r=0,(a=t)?`This golf video "${a.title}" by ${a.channel_name} discusses golf-related content based on the available transcript. The video appears to cover golf techniques, gameplay, or instruction.

[AI summarization temporarily unavailable - basic summary provided]`:`This golf video covers various golf-related topics based on the transcript content.

[AI summarization temporarily unavailable - basic summary provided]`}}async function w(e,t){try{let r=process.env.ELEVENLABS_API_KEY;if(!r)return console.log("ELEVENLABS_API_KEY not configured, skipping audio generation"),null;console.log("ElevenLabs API Key found:",r?"Yes":"No"),console.log("Text length for audio:",e.length);let a=e.replace(/\[AI-generated from video transcript\]/g,"").replace(/\*\*/g,"").replace(/\*/g,"").trim(),n=await fetch("https://api.elevenlabs.io/v1/text-to-speech/NOpBlnGInO9m6vDvFkFC",{method:"POST",headers:{"xi-api-key":r,"Content-Type":"application/json"},body:JSON.stringify({text:a,model_id:"eleven_multilingual_v2",voice_settings:{stability:.5,similarity_boost:.8,style:.2,use_speaker_boost:!0}})});if(!n.ok){console.error(`ElevenLabs API error: ${n.status} ${n.statusText}`);let e=await n.text();return console.error("Error details:",e),null}let i=await n.arrayBuffer();return await E(i,t)}catch(e){return console.error("Error generating ElevenLabs audio:",e),null}}async function E(e,t){let{promises:a}=r(29021),n=r(33873);try{let r=n.join(process.cwd(),"public","audio");await a.mkdir(r,{recursive:!0});let i=`jim-nantz-${t}.mp3`,o=n.join(r,i),s=Buffer.from(e);return await a.writeFile(o,s),`/audio/${i}`}catch(e){throw console.error("Error saving audio file:",e),e}}async function _(e){let t=await p.A.connect();try{let r=`
      SELECT result, captions_preview, audio_url
      FROM video_analyses
      WHERE youtube_url LIKE '%' || $1 || '%'
        AND status = 'COMPLETED'
        AND transcript_source IS NOT NULL
        AND transcript_source != 'none'
      ORDER BY created_at DESC
      LIMIT 1
    `,a=await t.query(r,[e]);if(a.rows.length>0){let e=a.rows[0];if(e.result)try{let t=JSON.parse(e.result);if(t.summary)return{summary:t.summary+"\n\n[Generated from video transcript]",audioUrl:e.audio_url}}catch(e){console.log("Could not parse existing analysis result")}if(e.captions_preview)return{summary:`Video Content Preview:
${e.captions_preview}

[Generated from video transcript]`,audioUrl:e.audio_url}}return null}finally{t.release()}}async function x(e,t,r){let a=await p.A.connect();try{let n=`https://youtube.com/watch?v=${e}`,i=`
      INSERT INTO video_analyses (
        youtube_url,
        status,
        result,
        transcript_source,
        audio_url,
        created_at,
        updated_at
      ) VALUES ($1, $2, $3, $4, $5, NOW(), NOW())
      ON CONFLICT (youtube_url) 
      DO UPDATE SET 
        result = EXCLUDED.result,
        transcript_source = EXCLUDED.transcript_source,
        audio_url = EXCLUDED.audio_url,
        updated_at = NOW()
    `,o=JSON.stringify({summary:t.replace("\n\n[Generated from video transcript]",""),source:"transcript_analysis",generated_at:new Date().toISOString()});await a.query(i,[n,"COMPLETED",o,"transcript",r]),console.log(`Saved transcript summary and audio for video ${e} to database`)}catch(e){console.error("Error saving transcript summary to database:",e)}finally{a.release()}}a()}catch(e){a(e)}})},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64939:e=>{"use strict";e.exports=import("pg")},78335:()=>{},79646:e=>{"use strict";e.exports=require("child_process")},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[4447,580],()=>r(22160));module.exports=a})();
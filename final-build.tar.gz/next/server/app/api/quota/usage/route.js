(()=>{var e={};e.id=2766,e.ids=[2766],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},6710:(e,t,a)=>{"use strict";a.a(e,async(e,s)=>{try{a.d(t,{A:()=>i});var r=a(64939),n=e([r]);let i=new(r=(n.then?(await n)():n)[0]).Pool({connectionString:process.env.DATABASE_URL||"postgresql://postgres:mysecretpassword@localhost/postgres",ssl:{rejectUnauthorized:!1},max:10,min:2,idleTimeoutMillis:6e4,connectionTimeoutMillis:5e3,acquireTimeoutMillis:1e4,statement_timeout:3e4,query_timeout:3e4});s()}catch(e){s(e)}})},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},37674:(e,t,a)=>{"use strict";a.a(e,async(e,s)=>{try{a.d(t,{n:()=>o});var r=a(6710),n=e([r]);r=(n.then?(await n)():n)[0];class i{static{this.DAILY_LIMIT=1e4}static{this.COSTS={search:100,videoList:1,channelList:1,playlistItems:1}}async recordUsage(e,t){let a=await r.A.connect();try{await a.query(`
        CREATE TABLE IF NOT EXISTS api_quota_usage (
          id SERIAL PRIMARY KEY,
          date DATE DEFAULT CURRENT_DATE,
          operation VARCHAR(50),
          units_used INTEGER,
          timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )
      `),await a.query(`
        CREATE INDEX IF NOT EXISTS idx_api_quota_date ON api_quota_usage(date)
      `),await a.query(`
        CREATE INDEX IF NOT EXISTS idx_api_quota_operation ON api_quota_usage(date, operation)
      `),await a.query(`
        INSERT INTO api_quota_usage (operation, units_used)
        VALUES ($1, $2)
      `,[e,t])}finally{a.release()}}async getTodayUsage(){let e=await r.A.connect();try{await e.query(`
        CREATE TABLE IF NOT EXISTS api_quota_usage (
          id SERIAL PRIMARY KEY,
          date DATE DEFAULT CURRENT_DATE,
          operation VARCHAR(50),
          units_used INTEGER,
          timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )
      `);let t=await e.query(`
        SELECT 
          COALESCE(SUM(units_used), 0) as total_units
        FROM api_quota_usage
        WHERE date = CURRENT_DATE
      `),a=await e.query(`
        SELECT 
          operation,
          COUNT(*) as count,
          SUM(units_used) as total
        FROM api_quota_usage
        WHERE date = CURRENT_DATE
        GROUP BY operation
      `),s={searches:0,video_updates:0,channel_checks:0};return a.rows.forEach(e=>{"search"===e.operation&&(s.searches=parseInt(e.count)),"video_update"===e.operation&&(s.video_updates=parseInt(e.count)),"channel_check"===e.operation&&(s.channel_checks=parseInt(e.count))}),{date:new Date().toISOString().split("T")[0],units_used:parseInt(t.rows[0].total_units),operations:s}}finally{e.release()}}async canPerformOperation(e){let t=await this.getTodayUsage(),a=i.COSTS[e]||1;return t.units_used+a<=i.DAILY_LIMIT}calculateBatchCost(e,t){switch(e){case"video_update":return Math.ceil(t/50)*i.COSTS.videoList;case"search":return t*i.COSTS.search;case"channel_check":return t*i.COSTS.channelList;default:return t}}}let o=new i;s()}catch(e){s(e)}})},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},45214:(e,t,a)=>{"use strict";a.a(e,async(e,s)=>{try{a.r(t),a.d(t,{GET:()=>o});var r=a(32190),n=a(37674),i=e([n]);async function o(e){try{let e=await n.n.getTodayUsage();return r.NextResponse.json({date:e.date,units_used:e.units_used,units_remaining:1e4-e.units_used,percentage_used:(e.units_used/1e4*100).toFixed(2)+"%",operations:e.operations,can_perform_search:e.units_used+100<=1e4,can_perform_batch_update:e.units_used+1<=1e4})}catch(e){return console.error("Failed to get quota usage:",e),r.NextResponse.json({error:"Failed to get quota usage",message:e instanceof Error?e.message:"Unknown error"},{status:500})}}n=(i.then?(await i)():i)[0],s()}catch(e){s(e)}})},49276:(e,t,a)=>{"use strict";a.a(e,async(e,s)=>{try{a.r(t),a.d(t,{patchFetch:()=>c,routeModule:()=>p,serverHooks:()=>E,workAsyncStorage:()=>d,workUnitAsyncStorage:()=>l});var r=a(96559),n=a(48088),i=a(37719),o=a(45214),u=e([o]);o=(u.then?(await u)():u)[0];let p=new r.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/quota/usage/route",pathname:"/api/quota/usage",filename:"route",bundlePath:"app/api/quota/usage/route"},resolvedPagePath:"/Users/dbrown/golfllm/frontend/golf-directory/src/app/api/quota/usage/route.ts",nextConfigOutput:"standalone",userland:o}),{workAsyncStorage:d,workUnitAsyncStorage:l,serverHooks:E}=p;function c(){return(0,i.patchFetch)({workAsyncStorage:d,workUnitAsyncStorage:l})}s()}catch(e){s(e)}})},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64939:e=>{"use strict";e.exports=import("pg")},78335:()=>{},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),s=t.X(0,[4447,580],()=>a(49276));module.exports=s})();
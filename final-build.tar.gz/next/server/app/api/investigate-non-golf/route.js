(()=>{var e={};e.id=1126,e.ids=[1126],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},6710:(e,t,o)=>{"use strict";o.a(e,async(e,i)=>{try{o.d(t,{A:()=>a});var n=o(64939),s=e([n]);let a=new(n=(s.then?(await s)():s)[0]).Pool({connectionString:process.env.DATABASE_URL||"postgresql://postgres:mysecretpassword@localhost/postgres",ssl:{rejectUnauthorized:!1},max:10,min:2,idleTimeoutMillis:6e4,connectionTimeoutMillis:5e3,acquireTimeoutMillis:1e4,statement_timeout:3e4,query_timeout:3e4});i()}catch(e){i(e)}})},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},40112:(e,t,o)=>{"use strict";o.a(e,async(e,i)=>{try{o.r(t),o.d(t,{GET:()=>r});var n=o(32190),s=o(6710),a=e([s]);async function r(){try{let e=await s.A.connect();try{let t={},o=[];for(let t of["Benjamin Cowen","Unisport","Crypto","Bitcoin","Soccer","Football","NBA","NFL","MLB","Cooking","Gaming","Music","Fashion","Beauty"]){let i=await e.query(`
          SELECT DISTINCT yc.id, yc.title, COUNT(yv.id) as video_count
          FROM youtube_channels yc
          JOIN youtube_videos yv ON yc.id = yv.channel_id
          WHERE LOWER(yc.title) LIKE LOWER($1)
          GROUP BY yc.id, yc.title
          ORDER BY video_count DESC
        `,[`%${t}%`]);i.rows.length>0&&o.push(...i.rows.map(e=>({...e,matched_keyword:t})))}t.nonGolfChannels=o;let i=[];for(let t of["crypto","bitcoin","ethereum","soccer","football","basketball","nba","nfl","cooking","recipe","gaming","music","fashion","makeup"]){let o=await e.query(`
          SELECT yv.id, yv.title, yc.title as channel_title, yv.view_count, yv.category
          FROM youtube_videos yv
          JOIN youtube_channels yc ON yv.channel_id = yc.id
          WHERE LOWER(yv.title) LIKE LOWER($1)
             AND LOWER(yv.title) NOT LIKE '%golf%'
          ORDER BY yv.view_count DESC
          LIMIT 5
        `,[`%${t}%`]);o.rows.length>0&&i.push(...o.rows.map(e=>({...e,matched_keyword:t})))}t.nonGolfVideos=i,t.suspiciousChannels=(await e.query(`
        SELECT yc.id, yc.title, 
               COUNT(yv.id) as total_videos,
               COUNT(CASE WHEN LOWER(yv.title) LIKE '%golf%' THEN 1 END) as golf_videos,
               COUNT(CASE WHEN LOWER(yv.title) NOT LIKE '%golf%' THEN 1 END) as non_golf_videos
        FROM youtube_channels yc
        JOIN youtube_videos yv ON yc.id = yv.channel_id
        GROUP BY yc.id, yc.title
        HAVING COUNT(CASE WHEN LOWER(yv.title) NOT LIKE '%golf%' THEN 1 END) > 0
           AND COUNT(CASE WHEN LOWER(yv.title) LIKE '%golf%' THEN 1 END) = 0
        ORDER BY total_videos DESC
        LIMIT 20
      `)).rows;let s=[];for(let t of["good","perfect","best","amazing"]){let o=await e.query(`
          SELECT 
            COUNT(*) as total,
            COUNT(CASE WHEN LOWER(yv.title) LIKE '%golf%' OR LOWER(yc.title) LIKE '%golf%' THEN 1 END) as golf_related,
            COUNT(CASE WHEN LOWER(yv.title) NOT LIKE '%golf%' AND LOWER(yc.title) NOT LIKE '%golf%' THEN 1 END) as non_golf
          FROM youtube_videos yv
          JOIN youtube_channels yc ON yv.channel_id = yc.id
          WHERE LOWER(yv.title) LIKE LOWER($1)
        `,[`%${t}%`]);o.rows[0].total>0&&s.push({term:t,...o.rows[0],non_golf_percentage:(o.rows[0].non_golf/o.rows[0].total*100).toFixed(1)})}return t.searchTermAnalysis=s,t.summary=(await e.query(`
        SELECT 
          (SELECT COUNT(*) FROM youtube_videos) as total_videos,
          (SELECT COUNT(*) FROM youtube_channels) as total_channels,
          (SELECT COUNT(DISTINCT channel_id) FROM youtube_videos 
           WHERE channel_id IN (
             SELECT yc.id FROM youtube_channels yc
             WHERE LOWER(yc.title) LIKE '%benjamin cowen%'
                OR LOWER(yc.title) LIKE '%unisport%'
                OR LOWER(yc.title) LIKE '%crypto%'
                OR LOWER(yc.title) LIKE '%bitcoin%'
                OR LOWER(yc.title) LIKE '%soccer%'
                OR LOWER(yc.title) LIKE '%football%'
                OR LOWER(yc.title) LIKE '%nba%'
           )) as non_golf_channel_count
      `)).rows[0],t.specificExamples=(await e.query(`
        SELECT yv.id, yv.title, yc.title as channel_title, yv.view_count, yv.published_at
        FROM youtube_videos yv
        JOIN youtube_channels yc ON yv.channel_id = yc.id
        WHERE LOWER(yc.title) LIKE '%benjamin cowen%'
           OR LOWER(yc.title) LIKE '%unisport%'
        ORDER BY yv.view_count DESC
        LIMIT 20
      `)).rows,n.NextResponse.json(t)}finally{e.release()}}catch(e){return n.NextResponse.json({error:"Investigation failed",message:e.message},{status:500})}}s=(a.then?(await a)():a)[0],i()}catch(e){i(e)}})},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},58380:(e,t,o)=>{"use strict";o.a(e,async(e,i)=>{try{o.r(t),o.d(t,{patchFetch:()=>c,routeModule:()=>E,serverHooks:()=>d,workAsyncStorage:()=>y,workUnitAsyncStorage:()=>u});var n=o(96559),s=o(48088),a=o(37719),r=o(40112),l=e([r]);r=(l.then?(await l)():l)[0];let E=new n.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/investigate-non-golf/route",pathname:"/api/investigate-non-golf",filename:"route",bundlePath:"app/api/investigate-non-golf/route"},resolvedPagePath:"/Users/dbrown/golfllm/frontend/golf-directory/src/app/api/investigate-non-golf/route.ts",nextConfigOutput:"standalone",userland:r}),{workAsyncStorage:y,workUnitAsyncStorage:u,serverHooks:d}=E;function c(){return(0,a.patchFetch)({workAsyncStorage:y,workUnitAsyncStorage:u})}i()}catch(e){i(e)}})},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64939:e=>{"use strict";e.exports=import("pg")},78335:()=>{},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var o=e=>t(t.s=e),i=t.X(0,[4447,580],()=>o(58380));module.exports=i})();
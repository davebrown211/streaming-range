(()=>{var e={};e.id=4317,e.ids=[4317],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},6710:(e,t,r)=>{"use strict";r.a(e,async(e,s)=>{try{r.d(t,{A:()=>o});var a=r(64939),n=e([a]);let o=new(a=(n.then?(await n)():n)[0]).Pool({connectionString:process.env.DATABASE_URL||"postgresql://postgres:mysecretpassword@localhost/postgres",ssl:!!process.env.DATABASE_URL?.includes("digitalocean")&&{rejectUnauthorized:!1,require:!0},max:10,min:2,idleTimeoutMillis:6e4,connectionTimeoutMillis:1e4,acquireTimeoutMillis:15e3,statement_timeout:3e4,query_timeout:3e4});s()}catch(e){s(e)}})},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},38119:(e,t,r)=>{"use strict";r.a(e,async(e,s)=>{try{r.r(t),r.d(t,{GET:()=>c,POST:()=>i});var a=r(32190),n=r(6710),o=e([n]);n=(o.then?(await o)():o)[0];let p=new Map;async function i(e,{params:t}){try{let{videoId:e}=await t,r=p.get(e);if(r&&Date.now()-r.timestamp<864e5)return a.NextResponse.json({summary:r.summary});let s=await n.A.connect();try{let t=`
        SELECT 
          yv.title,
          yv.description,
          yc.title as channel_name
        FROM youtube_videos yv
        JOIN youtube_channels yc ON yv.channel_id = yc.id
        WHERE yv.id = $1
      `,r=await s.query(t,[e]);if(0===r.rows.length)return a.NextResponse.json({error:"Video not found"},{status:404});let n=r.rows[0],o=`
        SELECT va.result, va.character_analysis, va.captions_preview
        FROM video_analyses va
        WHERE va.youtube_url LIKE '%' || $1 || '%'
          AND va.status = 'COMPLETED'
          AND va.result IS NOT NULL
      `,i=await s.query(o,[e]);if(i.rows.length>0){let t=i.rows[0],r=u(t,n);return p.set(e,{summary:r,timestamp:Date.now()}),a.NextResponse.json({summary:r})}let c=l(n);return p.set(e,{summary:c,timestamp:Date.now()}),a.NextResponse.json({summary:c})}finally{s.release()}}catch(e){return console.error("Error generating video summary:",e),a.NextResponse.json({error:"Failed to generate summary"},{status:500})}}function u(e,t){let r="";try{if(e.result){let t=JSON.parse(e.result);t.summary?r+=t.summary+"\n\n":t.analysis&&(r+=t.analysis+"\n\n"),(t.total_score||t.scores)&&(r+=`🏌️ Golf Performance: ${t.total_score||"Multiple scores recorded"}

`)}if(e.character_analysis){let t=JSON.parse(e.character_analysis);t&&t.length>0&&(r+="\uD83D\uDC65 Key Players:\n",t.slice(0,3).forEach(e=>{r+=`• ${e.name||"Player"}: ${e.role||e.personality||"Golf enthusiast"}
`}),r+="\n")}!r&&e.captions_preview&&(r=`📝 Video Content Preview:
${e.captions_preview.substring(0,300)}...

`)}catch(e){console.error("Error parsing analysis data:",e)}return!r&&t?l(t):r||"AI analysis completed but summary content is not available."}function l(e){let t=e.description||"No description available",r=t.length>200?t.substring(0,200)+"...":t;return`This video "${e.title}" by ${e.channel_name} is a golf-related content piece. ${r}

[AI-powered summary will be generated when the video is processed by our analysis system.]`}async function c(e,{params:t}){try{let{videoId:e}=await t,r=p.get(e);if(r&&Date.now()-r.timestamp<864e5)return a.NextResponse.json({summary:r.summary});let s=await n.A.connect();try{let t=`
        SELECT va.result, va.character_analysis, va.created_at
        FROM video_analyses va
        WHERE va.youtube_url LIKE '%' || $1 || '%'
          AND va.status = 'COMPLETED'
          AND va.result IS NOT NULL
      `,r=await s.query(t,[e]);if(0===r.rows.length)return a.NextResponse.json({error:"Summary not found"},{status:404});let n=r.rows[0],o=u(n);return p.set(e,{summary:o,timestamp:Date.now()}),a.NextResponse.json({summary:o,generated_at:n.created_at})}finally{s.release()}}catch(e){return console.error("Error fetching video summary:",e),a.NextResponse.json({error:"Failed to fetch summary"},{status:500})}}s()}catch(e){s(e)}})},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64939:e=>{"use strict";e.exports=import("pg")},78335:()=>{},84694:(e,t,r)=>{"use strict";r.a(e,async(e,s)=>{try{r.r(t),r.d(t,{patchFetch:()=>l,routeModule:()=>c,serverHooks:()=>y,workAsyncStorage:()=>p,workUnitAsyncStorage:()=>d});var a=r(96559),n=r(48088),o=r(37719),i=r(38119),u=e([i]);i=(u.then?(await u)():u)[0];let c=new a.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/video-summary/[videoId]/route",pathname:"/api/video-summary/[videoId]",filename:"route",bundlePath:"app/api/video-summary/[videoId]/route"},resolvedPagePath:"/Users/dbrown/golfllm/frontend/golf-directory/src/app/api/video-summary/[videoId]/route.ts",nextConfigOutput:"standalone",userland:i}),{workAsyncStorage:p,workUnitAsyncStorage:d,serverHooks:y}=c;function l(){return(0,o.patchFetch)({workAsyncStorage:p,workUnitAsyncStorage:d})}s()}catch(e){s(e)}})},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[4447,580],()=>r(84694));module.exports=s})();
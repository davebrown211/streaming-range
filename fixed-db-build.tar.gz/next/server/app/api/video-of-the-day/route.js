(()=>{var e={};e.id=7588,e.ids=[7588],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},6710:(e,t,a)=>{"use strict";a.a(e,async(e,o)=>{try{a.d(t,{A:()=>n});var r=a(64939),s=e([r]);let n=new(r=(s.then?(await s)():s)[0]).Pool({connectionString:process.env.DATABASE_URL||"postgresql://postgres:mysecretpassword@localhost/postgres",ssl:!!process.env.DATABASE_URL?.includes("digitalocean")&&{rejectUnauthorized:!1,require:!0},max:10,min:2,idleTimeoutMillis:6e4,connectionTimeoutMillis:1e4,acquireTimeoutMillis:15e3,statement_timeout:3e4,query_timeout:3e4});o()}catch(e){o(e)}})},9018:(e,t,a)=>{"use strict";a.a(e,async(e,o)=>{try{a.r(t),a.d(t,{GET:()=>l});var r=a(32190),s=a(6710),n=a(66718),i=e([s]);async function l(){try{let e=await s.A.connect();try{let t=`
        WITH trending_candidates AS (
          SELECT 
            yv.id,
            yv.title,
            yc.title as channel,
            yv.view_count,
            yv.like_count,
            yv.engagement_rate,
            yv.published_at,
            yv.view_velocity,
            yv.thumbnail_url,
            yv.duration_seconds,
            -- Include AI analysis data
            va.result as ai_analysis,
            va.character_analysis,
            va.captions_preview,
            va.status as analysis_status,
            -- Calculate "freshness score" - heavily prioritize recent videos
            CASE 
              WHEN yv.published_at >= (NOW() AT TIME ZONE 'America/Chicago')::date THEN yv.view_count * 1000   -- 1000x boost for today's videos
              WHEN yv.published_at >= NOW() - INTERVAL '24 hours' THEN yv.view_count * 100    -- 100x boost for last 24h
              WHEN yv.published_at >= NOW() - INTERVAL '48 hours' THEN yv.view_count * 10     -- 10x boost for last 48h
              WHEN yv.published_at >= NOW() - INTERVAL '72 hours' THEN yv.view_count * 1      -- Raw view count for 3 days
              ELSE yv.view_count * 0.001                                                      -- Very low score for older
            END as momentum_score
          FROM youtube_videos yv
          JOIN youtube_channels yc ON yv.channel_id = yc.id
          LEFT JOIN video_analyses va ON va.youtube_url LIKE '%' || yv.id || '%'
            AND va.status = 'COMPLETED'
          WHERE yv.published_at >= NOW() - INTERVAL '14 days'  -- Expand search window  
            AND yv.view_count > 100                           -- Much lower threshold to find recent content
            AND (yv.engagement_rate > 0.1 OR yv.engagement_rate IS NULL)  -- Allow null engagement for recent videos
            AND yv.thumbnail_url IS NOT NULL                  -- Must have thumbnail
            AND (yv.duration_seconds IS NULL OR yv.duration_seconds > 60)  -- Exclude shorts
            AND yv.channel_id = ANY($1::text[])               -- Only whitelisted creators
            AND yv.title !~ '[あ-ん]'  -- Exclude Japanese hiragana
            AND yv.title !~ '[ア-ン]'  -- Exclude Japanese katakana
            AND yv.title !~ '[一-龯]'  -- Exclude Chinese/Japanese kanji
            AND yv.title !~ '[\xc0-\xff]'  -- Exclude accented characters (Italian, French, etc.)
            AND yv.title NOT ILIKE '%volkswagen%'  -- Exclude VW Golf cars
            AND yv.title NOT ILIKE '%vw golf%'
            AND yv.title NOT ILIKE '%gta%'  -- Exclude GTA games
            AND yv.title NOT ILIKE '%forza%'  -- Exclude racing games
            AND yv.title NOT ILIKE '%drive beyond%'  -- Exclude racing games
            AND yv.title NOT ILIKE '%golf cart%'  -- Focus on golf sport, not carts
        )
        SELECT 
          id as video_id,
          title,
          channel,
          view_count,
          like_count,
          engagement_rate,
          published_at,
          view_velocity,
          thumbnail_url,
          duration_seconds,
          momentum_score,
          ai_analysis,
          character_analysis,
          captions_preview,
          analysis_status
        FROM trending_candidates
        ORDER BY momentum_score DESC, view_velocity DESC, engagement_rate DESC
        LIMIT 1
      `,a=await e.query(t,[n.mN]);if(0===a.rows.length)return r.NextResponse.json({error:"No video of the day found"},{status:404});let o=a.rows[0],s={video_id:o.video_id,title:o.title,channel:o.channel,views:(o.view_count||0).toString(),likes:(o.like_count||0).toString(),engagement:o.engagement_rate?`${o.engagement_rate.toFixed(2)}%`:"N/A",published:o.published_at.toISOString().split("T")[0],url:`https://youtube.com/watch?v=${o.video_id}`,thumbnail:o.thumbnail_url,view_velocity:Math.round(o.view_velocity),momentum_score:Math.round(o.momentum_score),duration_seconds:o.duration_seconds,is_short:o.duration_seconds&&o.duration_seconds<=60,days_ago:Math.floor((Date.now()-new Date(o.published_at).getTime())/864e5),has_ai_analysis:!!o.ai_analysis,analysis_status:o.analysis_status||null,ai_summary:o.ai_analysis?function(e){let t="";try{if(e.result){let a=JSON.parse(e.result);a.summary?t+=a.summary+"\n\n":a.analysis&&(t+=a.analysis+"\n\n"),(a.total_score||a.scores)&&(t+=`🏌️ Golf Performance: ${a.total_score||"Multiple scores recorded"}

`)}if(e.character_analysis){let a=JSON.parse(e.character_analysis);a&&a.length>0&&(t+="\uD83D\uDC65 Key Players:\n",a.slice(0,3).forEach(e=>{t+=`• ${e.name||"Player"}: ${e.role||e.personality||"Golf enthusiast"}
`}),t+="\n")}!t&&e.captions_preview&&(t=`📝 Video Content Preview:
${e.captions_preview.substring(0,300)}...

`)}catch(e){console.error("Error parsing analysis data:",e)}return t||"AI analysis completed but summary content is not available."}({result:o.ai_analysis,character_analysis:o.character_analysis,captions_preview:o.captions_preview}):null};return r.NextResponse.json(s,{headers:{"Cache-Control":"no-cache, no-store, must-revalidate",Pragma:"no-cache",Expires:"0"}})}finally{e.release()}}catch(e){return console.error("Error fetching video of the day:",e),r.NextResponse.json({error:"Internal server error"},{status:500})}}s=(i.then?(await i)():i)[0],o()}catch(e){o(e)}})},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},59288:(e,t,a)=>{"use strict";a.a(e,async(e,o)=>{try{a.r(t),a.d(t,{patchFetch:()=>c,routeModule:()=>d,serverHooks:()=>y,workAsyncStorage:()=>u,workUnitAsyncStorage:()=>g});var r=a(96559),s=a(48088),n=a(37719),i=a(9018),l=e([i]);i=(l.then?(await l)():l)[0];let d=new r.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/video-of-the-day/route",pathname:"/api/video-of-the-day",filename:"route",bundlePath:"app/api/video-of-the-day/route"},resolvedPagePath:"/Users/dbrown/golfllm/frontend/golf-directory/src/app/api/video-of-the-day/route.ts",nextConfigOutput:"standalone",userland:i}),{workAsyncStorage:u,workUnitAsyncStorage:g,serverHooks:y}=d;function c(){return(0,n.patchFetch)({workAsyncStorage:u,workUnitAsyncStorage:g})}o()}catch(e){o(e)}})},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64939:e=>{"use strict";e.exports=import("pg")},66718:(e,t,a)=>{"use strict";a.d(t,{mN:()=>r,zd:()=>s});let o=["good good","bob does sports","grant horvat","bryan bros","foreplay","dude perfect","gm golf","micah morris golf","garrett clark","tig","fat perez","the jet","cold cuts","bubbie","steve","matt","micah","brad dalke","lanto griffin","erik anders lang","the golfers journal","no laying up","fore the people","rick shiels","peter finch","mark crossfield","me and my golf","athletic motion golf","dan whittaker golf","golf monthly","golf.com","dan hendriksen","chris ryan golf","scratch golf academy","golf sidekick","james robinson golf","golf distillery","danny maude","alex elliott golf","golf swing simplified","top speed golf","golf tips magazine","rotary swing","eric cogorno","eric cogorno golf","cogorno golf","matt fryer golf","matt fryer","alex etches golf","alex etches","golf channel","the scratch golf show","scratch golf show","golf wrx","test golf","golf equipment guru","golf gurus","clay ballard","txg","golf monthly gear","2nd swing golf","fairway jockey","golf monthly reviews","fore fore","golf boys","golf life","scramble podcast","barstool golf","golf unfiltered","bad golf","golf beast","golf it","golf gods","golf time","ron chopper golf","ron chopper","luke kwon golf","luke kwon","the lads","phil mickelson","hyflyers","micah morris","tommy fleetwood","sean walsh","jake hutt golf","jake hutt","mytpi","titleist","taylormade","taylor made","garrett hilbert","tyler toney","brad dalke golf","stephen castaneda golf","ben polland golf","garrett johnston golf","amateur golf","golf with aimee","golf with aim","golf with friends","golf adventures","coffee and golf","golf diary","golf tales","big wedge golf","big wedge","padraig harrington","mrshortgame golf","mrshortgame","mr short game","jna golf","jna","bryan bros tv","josh mayer","golf girl games","girl golf games","golf life"],r=["UCfi-mPMOmche6WI-jkvnGXw","UCbY_v56iMzSGvXK79X6f4dw","UCqr4sONkmFEOPc3rfoVLEvg","UCgUueMmSpcl-aCTt5CuCKQw","UCJcc1x6emfrQquiV8Oe_pug","UCsazhBmAVDUL_WYcARQEFQA","UC3jFoA7_6BTV90hsRSVHoaw","UCfdYeBYjouhibG64ep_m4Vw","UCjchle1bmH0acutqK15_XSA","UCdCxaD8rWfAj12rloIYS6jQ","UCB0NRdlQ6fBYQX8W8bQyoDA","UCyy8ULLDGSm16_EkXdIt4Gw","UClJO9jvaU5mvNuP-XTbhHGw","UCFHZHhZaH7Rc_FOMIzUziJA","UCFoez1Xjc90CsHvCzqKnLcw","UCCxF55adGXOscJ3L8qdKnrQ","UCZelGnfKLXic4gDP63dIRxw","UCaeGjmOiTxekbGUDPKhoU-A","UCtNpbO2MtsVY4qW23WfnxGg","UCUOqlmPAo8h4pVQ4cuRECUg","UClljAz6ZKy0XeViKsohdjqA","UCSwdmDQhAi_-ICkAvNBLEBw","UCJolpQHWLAW6cCUYGgean8w","UCuXIBwKQeH9cnLOv7w66cJg","UCXvDkP2X3aE9yrPavNMJv0A","UCamOYT0c_pSrSCu9c8CyEcg","UCrgGz4gZxWu77Nw5RXcxlRg","UCCry5X3Phfmz0UzqRNm0BPA","UCwMgdK0S57nEdN_RGaajwOQ"];function s(e,t){if(t&&r.includes(t))return!0;let a=e.toLowerCase();return o.some(e=>a.includes(e.toLowerCase()))}},78335:()=>{},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),o=t.X(0,[4447,580],()=>a(59288));module.exports=o})();
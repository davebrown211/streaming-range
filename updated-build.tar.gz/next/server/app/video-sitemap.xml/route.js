(()=>{var e={};e.id=989,e.ids=[989],e.modules={175:(e,t,i)=>{"use strict";i.a(e,async(e,r)=>{try{i.r(t),i.d(t,{GET:()=>n});var o=i(32190),a=i(6710),s=e([a]);async function n(){try{let e=await a.A.connect(),t=await e.query(`
      SELECT 
        yv.id,
        yv.title,
        yv.published_at,
        yv.updated_at,
        yv.thumbnail_url,
        yv.duration_seconds,
        yc.title as channel_name,
        va.result as ai_summary
      FROM youtube_videos yv
      JOIN youtube_channels yc ON yv.channel_id = yc.id
      LEFT JOIN video_analyses va ON va.youtube_url LIKE '%' || yv.id || '%'
      WHERE yv.published_at >= NOW() - INTERVAL '30 days'
        AND yv.thumbnail_url IS NOT NULL
      ORDER BY yv.published_at DESC
      LIMIT 1000
    `);e.release();let i="https://golfdiscovery.com",r=`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:video="http://www.google.com/schemas/sitemap-video/1.1">
${t.rows.map(e=>{let t=e.ai_summary&&JSON.parse(e.ai_summary).summary?.slice(0,2048)||e.title;return`  <url>
    <loc>${i}/video/${e.id}</loc>
    <video:video>
      <video:thumbnail_loc>${e.thumbnail_url}</video:thumbnail_loc>
      <video:title><![CDATA[${e.title}]]></video:title>
      <video:description><![CDATA[${t}]]></video:description>
      <video:content_loc>https://youtube.com/watch?v=${e.id}</video:content_loc>
      <video:duration>${e.duration_seconds}</video:duration>
      <video:publication_date>${new Date(e.published_at).toISOString()}</video:publication_date>
      <video:family_friendly>yes</video:family_friendly>
      <video:uploader info="${i}">${e.channel_name}</video:uploader>
    </video:video>
    <lastmod>${new Date(e.updated_at||e.published_at).toISOString()}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>`}).join("\n")}
</urlset>`;return new o.NextResponse(r,{headers:{"Content-Type":"application/xml","Cache-Control":"public, s-maxage=3600, stale-while-revalidate=86400"}})}catch(e){return console.error("Error generating video sitemap:",e),new o.NextResponse("Error generating sitemap",{status:500})}}a=(s.then?(await s)():s)[0],r()}catch(e){r(e)}})},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},6710:(e,t,i)=>{"use strict";i.a(e,async(e,r)=>{try{i.d(t,{A:()=>s});var o=i(64939),a=e([o]);let s=new(o=(a.then?(await a)():a)[0]).Pool({connectionString:process.env.DATABASE_URL||"postgresql://postgres:mysecretpassword@localhost/postgres",ssl:{rejectUnauthorized:!1},max:10,min:2,idleTimeoutMillis:6e4,connectionTimeoutMillis:5e3,acquireTimeoutMillis:1e4,statement_timeout:3e4,query_timeout:3e4});r()}catch(e){r(e)}})},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64939:e=>{"use strict";e.exports=import("pg")},78335:()=>{},89266:(e,t,i)=>{"use strict";i.a(e,async(e,r)=>{try{i.r(t),i.d(t,{patchFetch:()=>d,routeModule:()=>u,serverHooks:()=>m,workAsyncStorage:()=>c,workUnitAsyncStorage:()=>p});var o=i(96559),a=i(48088),s=i(37719),n=i(175),l=e([n]);n=(l.then?(await l)():l)[0];let u=new o.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/video-sitemap.xml/route",pathname:"/video-sitemap.xml",filename:"route",bundlePath:"app/video-sitemap.xml/route"},resolvedPagePath:"/Users/dbrown/golfllm/frontend/golf-directory/src/app/video-sitemap.xml/route.ts",nextConfigOutput:"standalone",userland:n}),{workAsyncStorage:c,workUnitAsyncStorage:p,serverHooks:m}=u;function d(){return(0,s.patchFetch)({workAsyncStorage:c,workUnitAsyncStorage:p})}r()}catch(e){r(e)}})},96487:()=>{}};var t=require("../../webpack-runtime.js");t.C(e);var i=e=>t(t.s=e),r=t.X(0,[4447,580],()=>i(89266));module.exports=r})();
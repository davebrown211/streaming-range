(()=>{var e={};e.id=2366,e.ids=[2366],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},6710:(e,t,n)=>{"use strict";n.a(e,async(e,i)=>{try{n.d(t,{A:()=>s});var a=n(64939),r=e([a]);let s=new(a=(r.then?(await r)():r)[0]).Pool({connectionString:process.env.DATABASE_URL||"postgresql://postgres:mysecretpassword@localhost/postgres",ssl:{rejectUnauthorized:!1},max:10,min:2,idleTimeoutMillis:6e4,connectionTimeoutMillis:5e3,acquireTimeoutMillis:1e4,statement_timeout:3e4,query_timeout:3e4});i()}catch(e){i(e)}})},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},56962:(e,t,n)=>{"use strict";n.a(e,async(e,i)=>{try{n.r(t),n.d(t,{GET:()=>o});var a=n(32190),r=n(6710),s=e([r]);async function o(e,{params:t}){try{let{type:n}=await t,{searchParams:i}=new URL(e.url),s=Math.min(parseInt(i.get("limit")||"3"),20),o="true"===i.get("include_shorts"),l=["daily_trending","weekly_trending","all_time_views","high_engagement"];if(!l.includes(n))return a.NextResponse.json({error:`Invalid ranking type. Choose from: ${l.join(", ")}`},{status:400});let v=await r.A.connect();try{let e,t;"all_time_views"===n?(e=`
          WITH viral_videos AS (
            SELECT 
              yv.title,
              yc.title as channel,
              yv.view_count,
              yv.like_count,
              yv.engagement_rate,
              yv.published_at,
              yv.id as video_id,
              yv.thumbnail_url
            FROM youtube_videos yv
            JOIN youtube_channels yc ON yv.channel_id = yc.id
            WHERE yv.published_at >= NOW() - INTERVAL '7 days'
              AND yv.view_count > 50000
              ${o?"AND yv.duration_seconds IS NOT NULL AND yv.duration_seconds <= 60":"AND (yv.duration_seconds IS NULL OR yv.duration_seconds > 60)"}
            ORDER BY yv.view_count DESC
            LIMIT 100
          )
          SELECT 
            ROW_NUMBER() OVER (ORDER BY RANDOM()) as rank,
            *
          FROM viral_videos
          ORDER BY RANDOM()
          LIMIT $1
        `,t=[s]):"weekly_trending"===n?(e=`
          WITH trending_videos AS (
            SELECT 
              yv.title,
              yc.title as channel,
              yv.view_count,
              yv.like_count,
              yv.engagement_rate,
              yv.published_at,
              yv.id as video_id,
              yv.thumbnail_url,
              yv.view_acceleration,
              yv.view_velocity,
              (yv.view_velocity * 10) + 
              (yv.engagement_rate * 30) +
              (GREATEST(0, (336 - EXTRACT(EPOCH FROM (NOW() - yv.published_at))/3600)) / 336 * 500) as trending_score
            FROM youtube_videos yv
            JOIN youtube_channels yc ON yv.channel_id = yc.id
            WHERE yv.published_at >= NOW() - INTERVAL '30 days'
              AND yv.view_count < 500000
              AND yv.view_count > 1000
              ${o?"AND yv.duration_seconds IS NOT NULL AND yv.duration_seconds <= 60":"AND (yv.duration_seconds IS NULL OR yv.duration_seconds > 60)"}
              AND yv.id NOT IN (
                SELECT yv2.id FROM youtube_videos yv2 
                WHERE yv2.published_at >= NOW() - INTERVAL '7 days' 
                AND yv2.view_count > 50000
              )
            ORDER BY trending_score DESC
            LIMIT 50
          )
          SELECT 
            ROW_NUMBER() OVER (ORDER BY RANDOM()) as rank,
            title, channel, view_count, like_count, engagement_rate, 
            published_at, video_id, thumbnail_url, view_acceleration, view_velocity
          FROM trending_videos
          ORDER BY RANDOM()
          LIMIT $1
        `,t=[s]):"high_engagement"===n?(e=`
          WITH channel_total_views AS (
            SELECT 
              yc.id as channel_id,
              SUM(yv.view_count) as total_channel_views
            FROM youtube_channels yc
            JOIN youtube_videos yv ON yc.id = yv.channel_id
            GROUP BY yc.id
          ),
          hidden_gems AS (
            SELECT 
              yv.title,
              yc.title as channel,
              yv.view_count,
              yv.like_count,
              yv.engagement_rate,
              yv.published_at,
              yv.id as video_id,
              yv.thumbnail_url,
              (yv.engagement_rate * 60) + 
              (CASE WHEN yv.view_count > 100000 THEN 300 ELSE 0 END) +
              (CASE WHEN ctv.total_channel_views < 5000000 THEN 200 ELSE 0 END) as gem_score
            FROM youtube_videos yv
            JOIN youtube_channels yc ON yv.channel_id = yc.id
            JOIN channel_total_views ctv ON yc.id = ctv.channel_id
            WHERE yv.view_count > 8000
              AND yv.view_count < 3000000  -- Not mega-viral
              AND yv.engagement_rate > 2.5  -- Good engagement
              AND ctv.total_channel_views < 50000000  -- Smaller channels
              ${o?"AND yv.duration_seconds IS NOT NULL AND yv.duration_seconds <= 60":"AND (yv.duration_seconds IS NULL OR yv.duration_seconds > 60)"}
              -- Exclude mega-channels
              AND yc.title NOT ILIKE '%dude perfect%'
              AND yc.title NOT ILIKE '%good good%'
              AND yc.title NOT ILIKE '%pga tour%'
              AND yc.title NOT ILIKE '%espn%'
              AND yc.title NOT ILIKE '%bryson%'
              AND yc.title NOT ILIKE '%hammy golf%'
              -- Exclude current viral videos
              AND yv.id NOT IN (
                SELECT yv2.id FROM youtube_videos yv2 
                WHERE yv2.published_at >= NOW() - INTERVAL '7 days' 
                AND yv2.view_count > 200000
              )
            ORDER BY gem_score DESC
            LIMIT 100
          )
          SELECT 
            ROW_NUMBER() OVER (ORDER BY RANDOM()) as rank,
            title, channel, view_count, like_count, engagement_rate, 
            published_at, video_id, thumbnail_url
          FROM hidden_gems
          ORDER BY RANDOM()
          LIMIT $1
        `,t=[s]):"daily_trending"===n?(e=`
          SELECT 
            ROW_NUMBER() OVER (ORDER BY yv.view_count DESC) as rank,
            yv.title,
            yc.title as channel,
            yv.view_count,
            yv.like_count,
            yv.engagement_rate,
            yv.published_at,
            yv.id as video_id,
            yv.thumbnail_url
          FROM youtube_videos yv
          JOIN youtube_channels yc ON yv.channel_id = yc.id
          WHERE yv.published_at >= NOW() - INTERVAL '24 hours'
            ${o?"AND yv.duration_seconds IS NOT NULL AND yv.duration_seconds <= 60":"AND (yv.duration_seconds IS NULL OR yv.duration_seconds > 60)"}
            AND yv.title ~ '^[A-Za-z0-9$#"'']'  -- Must start with English letters/numbers or common chars
            AND yv.title !~ '[가-힣]'  -- Exclude Korean
            AND yv.title !~ '[あ-ん]'  -- Exclude Japanese hiragana
            AND yv.title !~ '[ア-ン]'  -- Exclude Japanese katakana
            AND yv.title !~ '[一-龯]'  -- Exclude Chinese/Japanese kanji
            AND yv.title !~ '[ก-๙]'  -- Exclude Thai
            AND yv.title !~ '[א-ת]'  -- Exclude Hebrew
            AND yv.title !~ '[ا-ي]'  -- Exclude Arabic
            AND yv.title !~ '[а-я]'  -- Exclude Cyrillic
            AND yv.title NOT ILIKE '%volkswagen%'  -- Exclude VW Golf cars
            AND yv.title NOT ILIKE '%vw golf%'
            AND yv.title NOT ILIKE '%gta%'  -- Exclude GTA games
            AND yv.title NOT ILIKE '%forza%'  -- Exclude racing games
            AND yv.title NOT ILIKE '%drive beyond%'  -- Exclude racing games
          ORDER BY yv.view_count DESC
          LIMIT $1
        `,t=[s]):(e=`
          SELECT 
            vr.rank,
            yv.title,
            yc.title as channel,
            yv.view_count,
            yv.like_count,
            yv.engagement_rate,
            yv.published_at,
            yv.id as video_id,
            yv.thumbnail_url
          FROM video_rankings vr
          JOIN youtube_videos yv ON vr.video_id = yv.id
          JOIN youtube_channels yc ON yv.channel_id = yc.id
          WHERE vr.ranking_type = $1
          ORDER BY vr.rank
          LIMIT $2
        `,t=[n,s]);let i=(await v.query(e,t)).rows.map(e=>({rank:e.rank,title:e.title,channel:e.channel,views:e.view_count.toLocaleString(),likes:e.like_count.toLocaleString(),engagement:`${e.engagement_rate.toFixed(2)}%`,published:e.published_at.toISOString().split("T")[0],url:`https://youtube.com/watch?v=${e.video_id}`,thumbnail:e.thumbnail_url||""}));return a.NextResponse.json(i)}finally{v.release()}}catch(e){return console.error("Error fetching rankings:",e),a.NextResponse.json({error:"Internal server error"},{status:500})}}r=(s.then?(await s)():s)[0],i()}catch(e){i(e)}})},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64939:e=>{"use strict";e.exports=import("pg")},78335:()=>{},83152:(e,t,n)=>{"use strict";n.a(e,async(e,i)=>{try{n.r(t),n.d(t,{patchFetch:()=>v,routeModule:()=>c,serverHooks:()=>d,workAsyncStorage:()=>y,workUnitAsyncStorage:()=>u});var a=n(96559),r=n(48088),s=n(37719),o=n(56962),l=e([o]);o=(l.then?(await l)():l)[0];let c=new a.AppRouteRouteModule({definition:{kind:r.RouteKind.APP_ROUTE,page:"/api/rankings/[type]/route",pathname:"/api/rankings/[type]",filename:"route",bundlePath:"app/api/rankings/[type]/route"},resolvedPagePath:"/Users/dbrown/golfllm/frontend/golf-directory/src/app/api/rankings/[type]/route.ts",nextConfigOutput:"standalone",userland:o}),{workAsyncStorage:y,workUnitAsyncStorage:u,serverHooks:d}=c;function v(){return(0,s.patchFetch)({workAsyncStorage:y,workUnitAsyncStorage:u})}i()}catch(e){i(e)}})},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var n=e=>t(t.s=e),i=t.X(0,[4447,580],()=>n(83152));module.exports=i})();
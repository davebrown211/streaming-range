"use strict";exports.id=326,exports.ids=[326],exports.modules={78175:(t,e,i)=>{i.a(t,async(t,a)=>{try{i.d(e,{i:()=>d});var n=i(6710),l=i(70664),o=i(74054),r=i(37674),c=t([n,o,r]);[n,o,r]=c.then?(await c)():c;class s{static{this.HIGH_PRIORITY_CHANNELS=[{id:"UCq-Cy3CK3r-qmjM7fXPqTlQ",title:"Good Good"},{id:"UCRvqjQPSeaWn-uEx-w0XOIg",title:"Dude Perfect"},{id:"UCgUueMmSpcl-aCTt5CuCKQw",title:"Grant Horvat Golf"},{id:"UCpzR85N5b5Cil_VE-P0HqWg",title:"Rick Shiels Golf"},{id:"UCGhLVzjASYN8oUxYBtfBfAw",title:"Peter Finch Golf"},{id:"UC5SQGzkWyQSW_fe-URgq7xw",title:"Bryson DeChambeau"},{id:"UCwOImVq9GMSalyC_uS3b-2Q",title:"TaylorMade Golf"},{id:"UCJKDS0Kym93MJSdhFqA8HTg",title:"Mark Crossfield"},{id:"UCm8OIxLBpNJFRbcnXJcXdNw",title:"Golf Sidekick"},{id:"UCbNRBQptR5CL4rX7eI3SWPQ",title:"James Robinson Golf"},{id:"UCqr4sONkmFEOPc3rfoVLEvg",title:"Bob Does Sports"},{id:"UClOp9ASmFYATO1zFfpB7QlA",title:"Eric Cogorno Golf"},{id:"UCokFauAYvXnr3e9TZQFESIQ",title:"Matt Fryer Golf"},{id:"UCJolpQHWLAW6cCUYGgean8w",title:"Padraig Harrington"},{id:"UC_GolfChannelID",title:"Golf Channel"}]}constructor(){this.youtubeClient=new l.Z}async initializeChannels(){let t=await n.A.connect();try{for(let e of(await t.query(`
        CREATE TABLE IF NOT EXISTS monitored_channels (
          id VARCHAR(255) PRIMARY KEY,
          title VARCHAR(255),
          priority VARCHAR(20) DEFAULT 'medium',
          last_checked TIMESTAMP WITH TIME ZONE,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )
      `),s.HIGH_PRIORITY_CHANNELS))await t.query(`
          INSERT INTO monitored_channels (id, title, priority)
          VALUES ($1, $2, $3)
          ON CONFLICT (id) DO UPDATE SET priority = $3
        `,[e.id,e.title,"high"])}finally{t.release()}}async discoverChannelsFromVideos(){let t=await n.A.connect();try{for(let e of(await t.query(`
        SELECT 
          yc.id,
          yc.title,
          COUNT(yv.id) as video_count,
          SUM(yv.view_count) as total_views
        FROM youtube_channels yc
        JOIN youtube_videos yv ON yc.id = yv.channel_id
        WHERE yc.id NOT IN (
          SELECT id FROM monitored_channels
        )
        GROUP BY yc.id, yc.title
        HAVING COUNT(yv.id) >= 2
        ORDER BY SUM(yv.view_count) DESC
        LIMIT 20
      `)).rows)await t.query(`
          INSERT INTO monitored_channels (id, title, priority)
          VALUES ($1, $2, $3)
          ON CONFLICT (id) DO NOTHING
        `,[e.id,e.title,"medium"])}finally{t.release()}}async checkChannelsForNewVideos(t=10){if(!await r.n.canPerformOperation("channel_check"))return console.log("Quota limit reached, skipping channel check"),0;let e=await n.A.connect();try{let i=await e.query(`
        SELECT id, title
        FROM monitored_channels
        WHERE last_checked IS NULL 
           OR last_checked < NOW() - INTERVAL '12 hours'
        ORDER BY 
          CASE priority 
            WHEN 'high' THEN 1 
            WHEN 'medium' THEN 2 
            ELSE 3 
          END,
          last_checked ASC NULLS FIRST
        LIMIT $1
      `,[t]),a=0;for(let t of i.rows)try{console.log(`Checking channel: ${t.title}`);let i=await this.youtubeClient.getChannelVideos(t.id,10);for(let t of(await r.n.recordUsage("channel_check",1),i))await o.T.upsertVideo(t),a++;await e.query(`
            UPDATE monitored_channels 
            SET last_checked = NOW() 
            WHERE id = $1
          `,[t.id])}catch(e){console.error(`Error checking channel ${t.title}:`,e)}return a}finally{e.release()}}async getMonitoredChannels(){let t=await n.A.connect();try{return(await t.query(`
        SELECT id, title, priority, last_checked
        FROM monitored_channels
        ORDER BY 
          CASE priority 
            WHEN 'high' THEN 1 
            WHEN 'medium' THEN 2 
            ELSE 3 
          END,
          title
      `)).rows.map(t=>({id:t.id,title:t.title,priority:t.priority,last_checked:t.last_checked}))}finally{t.release()}}}let d=new s;a()}catch(t){a(t)}})},80326:(t,e,i)=>{i.a(t,async(t,a)=>{try{i.r(e),i.d(e,{StartupManager:()=>c,default:()=>s});var n=i(51134),l=i(78175),o=i(6710),r=t([n,l,o]);[n,l,o]=r.then?(await r)():r;class c{static{this.initialized=!1}static async initialize(){if(!this.initialized){console.log("\uD83D\uDE80 Starting StreamingRange initialization...");try{await this.checkDatabase(),await this.initializeChannelMonitoring(),await this.ensureSchedulerRunning(),this.initialized=!0,console.log("✅ StreamingRange initialization complete!")}catch(t){throw console.error("❌ Startup initialization failed:",t),t}}}static async checkDatabase(){let t=3;for(;t>0;)try{let t=await o.A.connect();await t.query("SELECT 1"),t.release(),console.log("✅ Database connection verified");return}catch(e){if(t--,console.error(`❌ Database connection failed (${3-t}/3):`,e),0===t)throw e;await new Promise(t=>setTimeout(t,2e3))}}static async initializeChannelMonitoring(){try{await l.i.initializeChannels(),console.log("✅ Channel monitoring initialized")}catch(t){console.error("❌ Channel monitoring initialization failed:",t)}}static async ensureSchedulerRunning(){try{await new Promise(t=>setTimeout(t,6e3));let t=n.c.getStatus();if(t.isRunning)console.log(`✅ Scheduler already running with ${t.tasksCount} tasks`);else{console.log("⚡ Starting scheduler manually..."),n.c.start();let t=n.c.getStatus();t.isRunning?console.log(`✅ Scheduler started with ${t.tasksCount} tasks`):console.error("❌ Failed to start scheduler")}}catch(t){console.error("❌ Scheduler startup failed:",t)}}static getStatus(){return{initialized:this.initialized}}}setTimeout(()=>{c.initialize().catch(console.error)},1e3);let s=c;a()}catch(t){a(t)}})}};
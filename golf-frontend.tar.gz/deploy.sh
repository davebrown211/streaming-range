#!/bin/bash

# Golf Directory Deployment Script for DigitalOcean
# This script handles the deployment process with PM2

set -e  # Exit on error

echo "🚀 Starting Golf Directory Deployment..."

# Configuration
APP_NAME="golf-directory"
APP_DIR="/home/golf-directory"
NODE_VERSION="20"

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Function to print colored output
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
    exit 1
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   print_error "This script should not be run as root!"
fi

# Navigate to app directory
cd $APP_DIR || print_error "App directory not found"

# Pull latest code
echo "📥 Pulling latest code..."
git pull origin main || print_error "Failed to pull latest code"

# Install dependencies
echo "📦 Installing dependencies..."
npm ci || print_error "Failed to install dependencies"

# Build the application
echo "🔨 Building application..."
npm run build || print_error "Build failed"

# Run database migrations
echo "🗄️  Running database migrations..."
npm run db:migrate || print_error "Database migration failed"

# Copy production environment file if it doesn't exist
if [ ! -f .env.production ]; then
    if [ -f .env.production.example ]; then
        echo "📋 Creating .env.production from example..."
        cp .env.production.example .env.production
        print_error "Please update .env.production with your actual values and run deploy again"
    else
        print_error ".env.production file not found"
    fi
fi

# Stop the existing PM2 process
echo "🛑 Stopping existing process..."
pm2 stop $APP_NAME 2>/dev/null || echo "No existing process to stop"
pm2 delete $APP_NAME 2>/dev/null || echo "No existing process to delete"

# Start the application with PM2
echo "🚀 Starting application with PM2..."
pm2 start npm --name "$APP_NAME" -- start || print_error "Failed to start application"

# Save PM2 configuration
pm2 save || print_error "Failed to save PM2 configuration"

# Set PM2 to start on boot
pm2 startup systemd -u $USER --hp /home/$USER || echo "PM2 startup already configured"

print_success "Deployment completed successfully!"

# Show application status
echo ""
echo "📊 Application Status:"
pm2 status $APP_NAME

# Show logs
echo ""
echo "📜 Recent logs:"
pm2 logs $APP_NAME --lines 20 --nostream

echo ""
print_success "Golf Directory is now running at http://localhost:3000"
echo "Use 'pm2 logs $APP_NAME' to view logs"
echo "Use 'pm2 monit' for real-time monitoring"
(()=>{var e={};e.id=9190,e.ids=[9190],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},6710:(e,t,i)=>{"use strict";i.a(e,async(e,r)=>{try{i.d(t,{A:()=>s});var a=i(64939),o=e([a]);let s=new(a=(o.then?(await o)():o)[0]).Pool({connectionString:process.env.DATABASE_URL||"postgresql://postgres:mysecretpassword@localhost/postgres",max:10,min:2,idleTimeoutMillis:6e4,connectionTimeoutMillis:5e3,acquireTimeoutMillis:1e4,statement_timeout:3e4,query_timeout:3e4});r()}catch(e){r(e)}})},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},36234:(e,t,i)=>{"use strict";i.a(e,async(e,r)=>{try{i.r(t),i.d(t,{GET:()=>n});var a=i(32190),o=i(6710),s=e([o]);async function n(){try{let e=await o.A.connect();try{let t=`
        SELECT DISTINCT ON (yv.id)
          yv.id as video_id,
          yv.title,
          yc.title as channel,
          yv.view_count,
          yv.like_count,
          yv.engagement_rate,
          yv.published_at,
          yv.thumbnail_url,
          yv.duration_seconds,
          va.audio_url,
          va.result as ai_summary,
          va.created_at as audio_created_at,
          -- Calculate if this is today's video of the day
          CASE 
            WHEN yv.published_at >= (NOW() AT TIME ZONE 'America/Chicago')::date 
            THEN yv.view_count * 10 
            ELSE yv.view_count 
          END as momentum_score
        FROM youtube_videos yv
        JOIN youtube_channels yc ON yv.channel_id = yc.id
        JOIN video_analyses va ON va.youtube_url LIKE '%' || yv.id || '%'
        WHERE va.audio_url IS NOT NULL
          AND va.audio_url != ''
          AND va.status = 'COMPLETED'
        ORDER BY yv.id, va.created_at DESC
      `,i=await e.query(t),r=null;try{let e=await fetch(`${process.env.NEXTAUTH_URL||"http://localhost:3000"}/api/video-of-the-day`);e.ok&&(r=(await e.json()).video_id)}catch(a){console.error("Error fetching video of the day:",a);let t=`
          SELECT yv.id as video_id
          FROM youtube_videos yv
          WHERE yv.published_at >= NOW() - INTERVAL '24 hours'
            AND yv.view_count > 1000
            AND yv.thumbnail_url IS NOT NULL
          ORDER BY yv.view_count DESC
          LIMIT 1
        `,i=await e.query(t);r=i.rows[0]?.video_id}let o=i.rows.map(e=>({video_id:e.video_id,title:e.title,channel:e.channel,views:(e.view_count||0).toString(),likes:(e.like_count||0).toString(),engagement:`${e.engagement_rate.toFixed(2)}%`,published:e.published_at.toISOString().split("T")[0],url:`https://youtube.com/watch?v=${e.video_id}`,thumbnail:e.thumbnail_url,duration_seconds:e.duration_seconds,is_short:e.duration_seconds&&e.duration_seconds<=60,days_ago:Math.floor((Date.now()-new Date(e.published_at).getTime())/864e5),audio_url:e.audio_url,ai_summary:e.ai_summary,is_video_of_day:e.video_id===r}));return o.sort((e,t)=>e.is_video_of_day?-1:+!!t.is_video_of_day),a.NextResponse.json({videos:o})}finally{e.release()}}catch(e){return console.error("Error fetching videos with audio:",e),a.NextResponse.json({error:"Internal server error"},{status:500})}}o=(s.then?(await s)():s)[0],r()}catch(e){r(e)}})},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64939:e=>{"use strict";e.exports=import("pg")},78335:()=>{},87072:(e,t,i)=>{"use strict";i.a(e,async(e,r)=>{try{i.r(t),i.d(t,{patchFetch:()=>d,routeModule:()=>c,serverHooks:()=>_,workAsyncStorage:()=>l,workUnitAsyncStorage:()=>v});var a=i(96559),o=i(48088),s=i(37719),n=i(36234),u=e([n]);n=(u.then?(await u)():u)[0];let c=new a.AppRouteRouteModule({definition:{kind:o.RouteKind.APP_ROUTE,page:"/api/videos-with-audio/route",pathname:"/api/videos-with-audio",filename:"route",bundlePath:"app/api/videos-with-audio/route"},resolvedPagePath:"/Users/dbrown/golfllm/frontend/golf-directory/src/app/api/videos-with-audio/route.ts",nextConfigOutput:"standalone",userland:n}),{workAsyncStorage:l,workUnitAsyncStorage:v,serverHooks:_}=c;function d(){return(0,s.patchFetch)({workAsyncStorage:l,workUnitAsyncStorage:v})}r()}catch(e){r(e)}})},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var i=e=>t(t.s=e),r=t.X(0,[4447,580],()=>i(87072));module.exports=r})();
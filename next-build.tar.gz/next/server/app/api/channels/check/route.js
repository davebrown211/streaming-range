(()=>{var e={};e.id=9715,e.ids=[9715],e.modules={1708:e=>{"use strict";e.exports=require("node:process")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},4573:e=>{"use strict";e.exports=require("node:buffer")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},11723:e=>{"use strict";e.exports=require("querystring")},12412:e=>{"use strict";e.exports=require("assert")},15379:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.r(t),r.d(t,{POST:()=>c});var s=r(32190),a=r(78175),o=r(37674),n=e([a,o]);async function c(e){try{let{searchParams:t}=new URL(e.url),r=parseInt(t.get("limit")||"5"),i=await o.n.getTodayUsage(),n=await a.i.checkChannelsForNewVideos(r),c=await o.n.getTodayUsage();return s.NextResponse.json({message:"Channel check completed",channels_checked:r,new_videos_found:n,quota_used:c.units_used-i.units_used,total_quota_today:c.units_used,quota_remaining:1e4-c.units_used})}catch(e){return console.error("Channel check failed:",e),s.NextResponse.json({error:"Channel check failed",message:e instanceof Error?e.message:"Unknown error"},{status:500})}}[a,o]=n.then?(await n)():n,i()}catch(e){i(e)}})},16141:e=>{"use strict";e.exports=require("node:zlib")},19771:e=>{"use strict";e.exports=require("process")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},37067:e=>{"use strict";e.exports=require("node:http")},37674:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.d(t,{n:()=>n});var s=r(6710),a=e([s]);s=(a.then?(await a)():a)[0];class o{static{this.DAILY_LIMIT=1e4}static{this.COSTS={search:100,videoList:1,channelList:1,playlistItems:1}}async recordUsage(e,t){let r=await s.A.connect();try{await r.query(`
        CREATE TABLE IF NOT EXISTS api_quota_usage (
          id SERIAL PRIMARY KEY,
          date DATE DEFAULT CURRENT_DATE,
          operation VARCHAR(50),
          units_used INTEGER,
          timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )
      `),await r.query(`
        CREATE INDEX IF NOT EXISTS idx_api_quota_date ON api_quota_usage(date)
      `),await r.query(`
        CREATE INDEX IF NOT EXISTS idx_api_quota_operation ON api_quota_usage(date, operation)
      `),await r.query(`
        INSERT INTO api_quota_usage (operation, units_used)
        VALUES ($1, $2)
      `,[e,t])}finally{r.release()}}async getTodayUsage(){let e=await s.A.connect();try{await e.query(`
        CREATE TABLE IF NOT EXISTS api_quota_usage (
          id SERIAL PRIMARY KEY,
          date DATE DEFAULT CURRENT_DATE,
          operation VARCHAR(50),
          units_used INTEGER,
          timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )
      `);let t=await e.query(`
        SELECT 
          COALESCE(SUM(units_used), 0) as total_units
        FROM api_quota_usage
        WHERE date = CURRENT_DATE
      `),r=await e.query(`
        SELECT 
          operation,
          COUNT(*) as count,
          SUM(units_used) as total
        FROM api_quota_usage
        WHERE date = CURRENT_DATE
        GROUP BY operation
      `),i={searches:0,video_updates:0,channel_checks:0};return r.rows.forEach(e=>{"search"===e.operation&&(i.searches=parseInt(e.count)),"video_update"===e.operation&&(i.video_updates=parseInt(e.count)),"channel_check"===e.operation&&(i.channel_checks=parseInt(e.count))}),{date:new Date().toISOString().split("T")[0],units_used:parseInt(t.rows[0].total_units),operations:i}}finally{e.release()}}async canPerformOperation(e){let t=await this.getTodayUsage(),r=o.COSTS[e]||1;return t.units_used+r<=o.DAILY_LIMIT}calculateBatchCost(e,t){switch(e){case"video_update":return Math.ceil(t/50)*o.COSTS.videoList;case"search":return t*o.COSTS.search;case"channel_check":return t*o.COSTS.channelList;default:return t}}}let n=new o;i()}catch(e){i(e)}})},37830:e=>{"use strict";e.exports=require("node:stream/web")},44708:e=>{"use strict";e.exports=require("node:https")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},57075:e=>{"use strict";e.exports=require("node:stream")},57975:e=>{"use strict";e.exports=require("node:util")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64939:e=>{"use strict";e.exports=import("pg")},68334:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.r(t),r.d(t,{patchFetch:()=>u,routeModule:()=>l,serverHooks:()=>E,workAsyncStorage:()=>d,workUnitAsyncStorage:()=>p});var s=r(96559),a=r(48088),o=r(37719),n=r(15379),c=e([n]);n=(c.then?(await c)():c)[0];let l=new s.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/channels/check/route",pathname:"/api/channels/check",filename:"route",bundlePath:"app/api/channels/check/route"},resolvedPagePath:"/Users/dbrown/golfllm/frontend/golf-directory/src/app/api/channels/check/route.ts",nextConfigOutput:"standalone",userland:n}),{workAsyncStorage:d,workUnitAsyncStorage:p,serverHooks:E}=l;function u(){return(0,o.patchFetch)({workAsyncStorage:d,workUnitAsyncStorage:p})}i()}catch(e){i(e)}})},73024:e=>{"use strict";e.exports=require("node:fs")},73136:e=>{"use strict";e.exports=require("node:url")},73496:e=>{"use strict";e.exports=require("http2")},73566:e=>{"use strict";e.exports=require("worker_threads")},74075:e=>{"use strict";e.exports=require("zlib")},76760:e=>{"use strict";e.exports=require("node:path")},77030:e=>{"use strict";e.exports=require("node:net")},78175:(e,t,r)=>{"use strict";r.a(e,async(e,i)=>{try{r.d(t,{i:()=>l});var s=r(6710),a=r(70664),o=r(74054),n=r(37674),c=e([s,o,n]);[s,o,n]=c.then?(await c)():c;class u{static{this.HIGH_PRIORITY_CHANNELS=[{id:"UCq-Cy3CK3r-qmjM7fXPqTlQ",title:"Good Good"},{id:"UCRvqjQPSeaWn-uEx-w0XOIg",title:"Dude Perfect"},{id:"UCgUueMmSpcl-aCTt5CuCKQw",title:"Grant Horvat Golf"},{id:"UCpzR85N5b5Cil_VE-P0HqWg",title:"Rick Shiels Golf"},{id:"UCGhLVzjASYN8oUxYBtfBfAw",title:"Peter Finch Golf"},{id:"UC5SQGzkWyQSW_fe-URgq7xw",title:"Bryson DeChambeau"},{id:"UCwOImVq9GMSalyC_uS3b-2Q",title:"TaylorMade Golf"},{id:"UCJKDS0Kym93MJSdhFqA8HTg",title:"Mark Crossfield"},{id:"UCm8OIxLBpNJFRbcnXJcXdNw",title:"Golf Sidekick"},{id:"UCbNRBQptR5CL4rX7eI3SWPQ",title:"James Robinson Golf"},{id:"UCqr4sONkmFEOPc3rfoVLEvg",title:"Bob Does Sports"},{id:"UClOp9ASmFYATO1zFfpB7QlA",title:"Eric Cogorno Golf"},{id:"UCokFauAYvXnr3e9TZQFESIQ",title:"Matt Fryer Golf"},{id:"UCJolpQHWLAW6cCUYGgean8w",title:"Padraig Harrington"},{id:"UC_GolfChannelID",title:"Golf Channel"}]}constructor(){this.youtubeClient=new a.Z}async initializeChannels(){let e=await s.A.connect();try{for(let t of(await e.query(`
        CREATE TABLE IF NOT EXISTS monitored_channels (
          id VARCHAR(255) PRIMARY KEY,
          title VARCHAR(255),
          priority VARCHAR(20) DEFAULT 'medium',
          last_checked TIMESTAMP WITH TIME ZONE,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )
      `),u.HIGH_PRIORITY_CHANNELS))await e.query(`
          INSERT INTO monitored_channels (id, title, priority)
          VALUES ($1, $2, $3)
          ON CONFLICT (id) DO UPDATE SET priority = $3
        `,[t.id,t.title,"high"])}finally{e.release()}}async discoverChannelsFromVideos(){let e=await s.A.connect();try{for(let t of(await e.query(`
        SELECT 
          yc.id,
          yc.title,
          COUNT(yv.id) as video_count,
          SUM(yv.view_count) as total_views
        FROM youtube_channels yc
        JOIN youtube_videos yv ON yc.id = yv.channel_id
        WHERE yc.id NOT IN (
          SELECT id FROM monitored_channels
        )
        GROUP BY yc.id, yc.title
        HAVING COUNT(yv.id) >= 2
        ORDER BY SUM(yv.view_count) DESC
        LIMIT 20
      `)).rows)await e.query(`
          INSERT INTO monitored_channels (id, title, priority)
          VALUES ($1, $2, $3)
          ON CONFLICT (id) DO NOTHING
        `,[t.id,t.title,"medium"])}finally{e.release()}}async checkChannelsForNewVideos(e=10){if(!await n.n.canPerformOperation("channel_check"))return console.log("Quota limit reached, skipping channel check"),0;let t=await s.A.connect();try{let r=await t.query(`
        SELECT id, title
        FROM monitored_channels
        WHERE last_checked IS NULL 
           OR last_checked < NOW() - INTERVAL '12 hours'
        ORDER BY 
          CASE priority 
            WHEN 'high' THEN 1 
            WHEN 'medium' THEN 2 
            ELSE 3 
          END,
          last_checked ASC NULLS FIRST
        LIMIT $1
      `,[e]),i=0;for(let e of r.rows)try{console.log(`Checking channel: ${e.title}`);let r=await this.youtubeClient.getChannelVideos(e.id,10);for(let e of(await n.n.recordUsage("channel_check",1),r))await o.T.upsertVideo(e),i++;await t.query(`
            UPDATE monitored_channels 
            SET last_checked = NOW() 
            WHERE id = $1
          `,[e.id])}catch(t){console.error(`Error checking channel ${e.title}:`,t)}return i}finally{t.release()}}async getMonitoredChannels(){let e=await s.A.connect();try{return(await e.query(`
        SELECT id, title, priority, last_checked
        FROM monitored_channels
        ORDER BY 
          CASE priority 
            WHEN 'high' THEN 1 
            WHEN 'medium' THEN 2 
            ELSE 3 
          END,
          title
      `)).rows.map(e=>({id:e.id,title:e.title,priority:e.priority,last_checked:e.last_checked}))}finally{e.release()}}}let l=new u;i()}catch(e){i(e)}})},78335:()=>{},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},81630:e=>{"use strict";e.exports=require("http")},83997:e=>{"use strict";e.exports=require("tty")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[4447,580,5976,4054],()=>r(68334));module.exports=i})();
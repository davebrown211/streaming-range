(()=>{var e={};e.id=3660,e.ids=[3660],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},6710:(e,t,r)=>{"use strict";r.a(e,async(e,s)=>{try{r.d(t,{A:()=>o});var a=r(64939),i=e([a]);let o=new(a=(i.then?(await i)():i)[0]).Pool({connectionString:process.env.DATABASE_URL||"postgresql://postgres:mysecretpassword@localhost/postgres",max:10,min:2,idleTimeoutMillis:6e4,connectionTimeoutMillis:5e3,acquireTimeoutMillis:1e4,statement_timeout:3e4,query_timeout:3e4});s()}catch(e){s(e)}})},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},28920:(e,t,r)=>{"use strict";r.a(e,async(e,s)=>{try{r.r(t),r.d(t,{patchFetch:()=>c,routeModule:()=>d,serverHooks:()=>v,workAsyncStorage:()=>l,workUnitAsyncStorage:()=>p});var a=r(96559),i=r(48088),o=r(37719),n=r(38382),u=e([n]);n=(u.then?(await u)():u)[0];let d=new a.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/debug-data/route",pathname:"/api/debug-data",filename:"route",bundlePath:"app/api/debug-data/route"},resolvedPagePath:"/Users/dbrown/golfllm/frontend/golf-directory/src/app/api/debug-data/route.ts",nextConfigOutput:"standalone",userland:n}),{workAsyncStorage:l,workUnitAsyncStorage:p,serverHooks:v}=d;function c(){return(0,o.patchFetch)({workAsyncStorage:l,workUnitAsyncStorage:p})}s()}catch(e){s(e)}})},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},38382:(e,t,r)=>{"use strict";r.a(e,async(e,s)=>{try{r.r(t),r.d(t,{GET:()=>n});var a=r(32190),i=r(6710),o=e([i]);async function n(){try{let e=await i.A.connect();try{let t={totalVideos:"SELECT COUNT(*) as count FROM youtube_videos",recentVideos:`
          SELECT COUNT(*) as count 
          FROM youtube_videos 
          WHERE published_at >= NOW() - INTERVAL '14 days'
        `,viewCountRange:`
          SELECT 
            MIN(view_count) as min_views,
            MAX(view_count) as max_views,
            AVG(view_count) as avg_views
          FROM youtube_videos
        `,accelerationData:`
          SELECT 
            COUNT(*) as total,
            COUNT(CASE WHEN view_acceleration > 0 THEN 1 END) as positive_accel,
            AVG(view_acceleration) as avg_accel
          FROM youtube_videos
          WHERE view_acceleration IS NOT NULL
        `,sampleVideos:`
          SELECT 
            title, view_count, view_velocity, view_acceleration, 
            engagement_rate, published_at
          FROM youtube_videos 
          ORDER BY published_at DESC 
          LIMIT 10
        `,viewHistory:`
          SELECT COUNT(*) as count 
          FROM video_view_history
        `},r={};for(let[s,a]of Object.entries(t))try{let t=await e.query(a);r[s]=t.rows}catch(e){r[s]={error:e.message}}return a.NextResponse.json(r)}finally{e.release()}}catch(e){return a.NextResponse.json({error:"Debug failed",message:e.message},{status:500})}}i=(o.then?(await o)():o)[0],s()}catch(e){s(e)}})},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64939:e=>{"use strict";e.exports=import("pg")},78335:()=>{},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[4447,580],()=>r(28920));module.exports=s})();
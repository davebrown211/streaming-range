(()=>{var e={};e.id=4869,e.ids=[4869],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},6710:(e,t,n)=>{"use strict";n.a(e,async(e,o)=>{try{n.d(t,{A:()=>a});var r=n(64939),s=e([r]);let a=new(r=(s.then?(await s)():s)[0]).Pool({connectionString:process.env.DATABASE_URL||"postgresql://postgres:mysecretpassword@localhost/postgres",max:10,min:2,idleTimeoutMillis:6e4,connectionTimeoutMillis:5e3,acquireTimeoutMillis:1e4,statement_timeout:3e4,query_timeout:3e4});o()}catch(e){o(e)}})},7238:(e,t,n)=>{"use strict";n.a(e,async(e,o)=>{try{n.r(t),n.d(t,{patchFetch:()=>c,routeModule:()=>y,serverHooks:()=>p,workAsyncStorage:()=>u,workUnitAsyncStorage:()=>E});var r=n(96559),s=n(48088),a=n(37719),i=n(84245),l=e([i]);i=(l.then?(await l)():l)[0];let y=new r.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/analyze-search-terms/route",pathname:"/api/analyze-search-terms",filename:"route",bundlePath:"app/api/analyze-search-terms/route"},resolvedPagePath:"/Users/dbrown/golfllm/frontend/golf-directory/src/app/api/analyze-search-terms/route.ts",nextConfigOutput:"standalone",userland:i}),{workAsyncStorage:u,workUnitAsyncStorage:E,serverHooks:p}=y;function c(){return(0,a.patchFetch)({workAsyncStorage:u,workUnitAsyncStorage:E})}o()}catch(e){o(e)}})},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64939:e=>{"use strict";e.exports=import("pg")},78335:()=>{},84245:(e,t,n)=>{"use strict";n.a(e,async(e,o)=>{try{n.r(t),n.d(t,{GET:()=>i});var r=n(32190),s=n(6710),a=e([s]);async function i(){try{let e=await s.A.connect();try{let t={};for(let n of["Good Good","Dude Perfect","perfect","good","best"]){let o=await e.query(`
          SELECT 
            yv.id,
            yv.title,
            yc.title as channel_title,
            yv.view_count,
            yv.category,
            CASE 
              WHEN LOWER(yv.title) LIKE '%golf%' OR LOWER(yc.title) LIKE '%golf%' THEN 'Golf Related'
              WHEN LOWER(yc.title) LIKE '%benjamin cowen%' THEN 'Crypto Content'
              WHEN LOWER(yc.title) LIKE '%unisport%' THEN 'Soccer Content'
              WHEN LOWER(yv.title) LIKE '%crypto%' OR LOWER(yv.title) LIKE '%bitcoin%' THEN 'Crypto Content'
              WHEN LOWER(yv.title) LIKE '%soccer%' OR LOWER(yv.title) LIKE '%football%' THEN 'Soccer/Football Content'
              WHEN LOWER(yv.title) LIKE '%basketball%' OR LOWER(yv.title) LIKE '%nba%' THEN 'Basketball Content'
              ELSE 'Other Non-Golf'
            END as content_type
          FROM youtube_videos yv
          JOIN youtube_channels yc ON yv.channel_id = yc.id
          WHERE LOWER(yv.title) LIKE LOWER($1) OR LOWER(yc.title) LIKE LOWER($1)
          ORDER BY yv.view_count DESC
          LIMIT 20
        `,[`%${n}%`]),r={term:n,total_matches:o.rows.length,content_breakdown:{}};for(let e of o.rows)r.content_breakdown[e.content_type]||(r.content_breakdown[e.content_type]={count:0,examples:[]}),r.content_breakdown[e.content_type].count++,r.content_breakdown[e.content_type].examples.length<3&&r.content_breakdown[e.content_type].examples.push({title:e.title,channel:e.channel_title,views:e.view_count});t[n]=r}let n=await e.query(`
        SELECT 
          yv.id,
          yv.title,
          yv.view_count,
          yv.category,
          CASE 
            WHEN LOWER(yv.title) LIKE '%golf%' THEN 'Golf Content'
            WHEN LOWER(yv.title) LIKE '%football%' OR LOWER(yv.title) LIKE '%nfl%' THEN 'Football Content'
            WHEN LOWER(yv.title) LIKE '%basketball%' OR LOWER(yv.title) LIKE '%nba%' THEN 'Basketball Content'
            ELSE 'Other Sports/Entertainment'
          END as content_type
        FROM youtube_videos yv
        JOIN youtube_channels yc ON yv.channel_id = yc.id
        WHERE yc.title = 'Dude Perfect'
        ORDER BY yv.view_count DESC
      `);for(let e of(t["Dude Perfect Channel Analysis"]={total_videos:n.rows.length,content_types:{}},n.rows))t["Dude Perfect Channel Analysis"].content_types[e.content_type]||(t["Dude Perfect Channel Analysis"].content_types[e.content_type]={count:0,videos:[]}),t["Dude Perfect Channel Analysis"].content_types[e.content_type].count++,t["Dude Perfect Channel Analysis"].content_types[e.content_type].videos.push({title:e.title,views:e.view_count,category:e.category});return r.NextResponse.json(t)}finally{e.release()}}catch(e){return r.NextResponse.json({error:"Analysis failed",message:e.message},{status:500})}}s=(a.then?(await a)():a)[0],o()}catch(e){o(e)}})},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var n=e=>t(t.s=e),o=t.X(0,[4447,580],()=>n(7238));module.exports=o})();
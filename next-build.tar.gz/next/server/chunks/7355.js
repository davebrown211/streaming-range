exports.id=7355,exports.ids=[7355],exports.modules={25339:(e,t,a)=>{"use strict";a.a(e,async(e,o)=>{try{a.d(t,{T:()=>l});var i=a(6710),s=a(66718),n=e([i]);i=(n.then?(await n)():n)[0];class r{async calculateQualityScore(e){let t={engagement:this.calculateEngagementScore(e),freshness:this.calculateFreshnessScore(e.published_at),whitelisted:this.calculateWhitelistScore(e.channel_name,e.channel_id),velocity:this.calculateVelocityScore(e.view_velocity||0,e.view_acceleration||0),duration:this.calculateDurationScore(e.duration_seconds)},a={engagement:.3,freshness:.2,whitelisted:.25,velocity:.15,duration:.1},o=Math.round(t.engagement*a.engagement+t.freshness*a.freshness+t.whitelisted*a.whitelisted+t.velocity*a.velocity+t.duration*a.duration),i=this.generateReasoning(t,e);return{overall:Math.min(100,Math.max(0,o)),factors:t,reasoning:i}}calculateEngagementScore(e){if(0===e.view_count)return 0;let t=(e.like_count+e.comment_count)/e.view_count*100;return t>=8?100:t>=5?85:t>=3?70:t>=2?55:t>=1?40:t>=.5?25:10}calculateFreshnessScore(e){let t=(Date.now()-e.getTime())/36e5;return t<=1?100:t<=6?90:t<=24?80:t<=72?65:t<=168?50:t<=720?30:10}calculateWhitelistScore(e,t){return(0,s.zd)(e,t)?100:20}calculateVelocityScore(e,t){let a=Math.min(100,Math.max(0,10*e)),o=t>0?Math.min(20,5*t):0;return Math.min(100,a+o)}calculateDurationScore(e){let t=e/60;return t>=5&&t<=20?100:t>=3&&t<=30?80:t>=1&&t<=45?60:t>=.5&&t<=60?40:20}generateReasoning(e,t){let a=[];return e.whitelisted>=80?a.push("✅ From trusted golf creator"):a.push("⚠️ Not from whitelisted creator"),e.engagement>=70?a.push("\uD83D\uDCC8 High engagement rate"):e.engagement>=40?a.push("\uD83D\uDCCA Moderate engagement"):a.push("\uD83D\uDCC9 Low engagement rate"),e.freshness>=80?a.push("\uD83C\uDD95 Very recent content"):e.freshness>=50?a.push("⏰ Recent content"):a.push("\uD83D\uDCC5 Older content"),e.velocity>=70?a.push("\uD83D\uDE80 Trending rapidly"):e.velocity>=40&&a.push("\uD83D\uDCC8 Gaining momentum"),e.duration>=80&&a.push("⏱️ Optimal duration"),a}async updateQualityScores(e=100){let t=await i.A.connect();try{let a=await t.query(`
        SELECT 
          yv.id, yv.title, yc.title as channel_name, yv.channel_id,
          yv.view_count, yv.like_count, yv.comment_count, yv.published_at,
          yv.duration_seconds, yv.view_velocity, yv.view_acceleration
        FROM youtube_videos yv
        JOIN youtube_channels yc ON yv.channel_id = yc.id
        WHERE yv.quality_score IS NULL 
           OR yv.quality_updated_at < NOW() - INTERVAL '6 hours'
        ORDER BY yv.published_at DESC
        LIMIT $1
      `,[e]),o=0;for(let e of a.rows)try{let a=await this.calculateQualityScore(e);await t.query(`
            UPDATE youtube_videos 
            SET quality_score = $1, 
                quality_factors = $2,
                quality_reasoning = $3,
                quality_updated_at = NOW()
            WHERE id = $1
          `,[a.overall,JSON.stringify(a.factors),JSON.stringify(a.reasoning),e.id]),o++}catch(t){console.error(`Quality scoring error for video ${e.id}:`,t)}return o}finally{t.release()}}async getTopQualityVideos(e=20){let t=await i.A.connect();try{return(await t.query(`
        SELECT 
          yv.id, yv.title, yc.title as channel, yv.view_count,
          yv.quality_score, yv.quality_reasoning, yv.published_at,
          yv.thumbnail_url
        FROM youtube_videos yv
        JOIN youtube_channels yc ON yv.channel_id = yc.id
        WHERE yv.quality_score IS NOT NULL
          AND yv.published_at >= NOW() - INTERVAL '7 days'
        ORDER BY yv.quality_score DESC, yv.view_count DESC
        LIMIT $1
      `,[e])).rows}finally{t.release()}}}let l=new r;o()}catch(e){o(e)}})},37674:(e,t,a)=>{"use strict";a.a(e,async(e,o)=>{try{a.d(t,{n:()=>r});var i=a(6710),s=e([i]);i=(s.then?(await s)():s)[0];class n{static{this.DAILY_LIMIT=1e4}static{this.COSTS={search:100,videoList:1,channelList:1,playlistItems:1}}async recordUsage(e,t){let a=await i.A.connect();try{await a.query(`
        CREATE TABLE IF NOT EXISTS api_quota_usage (
          id SERIAL PRIMARY KEY,
          date DATE DEFAULT CURRENT_DATE,
          operation VARCHAR(50),
          units_used INTEGER,
          timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )
      `),await a.query(`
        CREATE INDEX IF NOT EXISTS idx_api_quota_date ON api_quota_usage(date)
      `),await a.query(`
        CREATE INDEX IF NOT EXISTS idx_api_quota_operation ON api_quota_usage(date, operation)
      `),await a.query(`
        INSERT INTO api_quota_usage (operation, units_used)
        VALUES ($1, $2)
      `,[e,t])}finally{a.release()}}async getTodayUsage(){let e=await i.A.connect();try{await e.query(`
        CREATE TABLE IF NOT EXISTS api_quota_usage (
          id SERIAL PRIMARY KEY,
          date DATE DEFAULT CURRENT_DATE,
          operation VARCHAR(50),
          units_used INTEGER,
          timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )
      `);let t=await e.query(`
        SELECT 
          COALESCE(SUM(units_used), 0) as total_units
        FROM api_quota_usage
        WHERE date = CURRENT_DATE
      `),a=await e.query(`
        SELECT 
          operation,
          COUNT(*) as count,
          SUM(units_used) as total
        FROM api_quota_usage
        WHERE date = CURRENT_DATE
        GROUP BY operation
      `),o={searches:0,video_updates:0,channel_checks:0};return a.rows.forEach(e=>{"search"===e.operation&&(o.searches=parseInt(e.count)),"video_update"===e.operation&&(o.video_updates=parseInt(e.count)),"channel_check"===e.operation&&(o.channel_checks=parseInt(e.count))}),{date:new Date().toISOString().split("T")[0],units_used:parseInt(t.rows[0].total_units),operations:o}}finally{e.release()}}async canPerformOperation(e){let t=await this.getTodayUsage(),a=n.COSTS[e]||1;return t.units_used+a<=n.DAILY_LIMIT}calculateBatchCost(e,t){switch(e){case"video_update":return Math.ceil(t/50)*n.COSTS.videoList;case"search":return t*n.COSTS.search;case"channel_check":return t*n.COSTS.channelList;default:return t}}}let r=new n;o()}catch(e){o(e)}})},39727:()=>{},47990:()=>{},51134:(e,t,a)=>{"use strict";a.a(e,async(e,o)=>{try{a.d(t,{c:()=>p});var i=a(42703),s=a.n(i),n=a(76786),r=a(6710),l=a(74054),c=a(37674),d=a(25339),u=a(66718),h=a(61107),y=e([r,l,c,d]);[r,l,c,d]=y.then?(await y)():y;class g{start(){if(this.isRunning)return void console.log("Scheduler already running");console.log("Starting Golf Directory scheduler..."),this.isRunning=!0;let e=s().schedule("*/2 * * * *",async()=>{try{await this.performViewCountUpdates()}catch(e){console.error("FATAL: View count update task crashed:",e)}},{scheduled:!1}),t=s().schedule("*/30 * * * *",async()=>{try{await this.performCollectTodayVideos()}catch(e){console.error("FATAL: Collect today videos task crashed:",e)}},{scheduled:!1}),a=s().schedule("0 3 * * *",async()=>{try{await this.performMaintenanceUpdate()}catch(e){console.error("FATAL: Maintenance update task crashed:",e)}},{scheduled:!1});this.tasks.set("viewUpdates",e),this.tasks.set("collectToday",t),this.tasks.set("maintenance",a),e.start(),t.start(),a.start(),console.log("Scheduler tasks started:"),console.log("- View count updates: Every 2 minutes"),console.log("- Collect today videos: Every 30 minutes"),console.log("- Maintenance update: Daily at 3 AM"),console.log("Running initial collect today videos on startup..."),setTimeout(()=>{this.performCollectTodayVideos()},5e3),this.startHeartbeat()}stop(){console.log("Stopping scheduler..."),this.tasks.forEach((e,t)=>{e.stop(),console.log(`Stopped task: ${t}`)}),this.tasks.clear(),this.isRunning=!1,this.heartbeatInterval&&(clearInterval(this.heartbeatInterval),this.heartbeatInterval=null)}startHeartbeat(){console.log("Starting scheduler heartbeat monitoring..."),this.heartbeatInterval=setInterval(()=>{this.lastHeartbeat=Date.now(),console.log(`Scheduler heartbeat: ${this.tasks.size} tasks active, running: ${this.isRunning}`),this.isRunning&&0===this.tasks.size&&(console.warn("Scheduler shows running but no tasks active! Fixing state..."),this.isRunning=!1)},3e4)}restart(){console.log("Restarting scheduler..."),this.stop(),setTimeout(()=>{this.start()},2e3)}async performViewCountUpdates(){console.log("View count update...",new Date().toISOString());try{if(!await c.n.canPerformOperation("videoList"))return void console.log("Quota limit reached, skipping view updates");let e=await r.A.connect();try{let t=`
          WITH user_facing_videos AS (
            -- Videos from curated-videos API (whitelisted creators, recent uploads)
            (SELECT yv.id, yv.view_count, yv.title, yc.title as channel_name, yv.updated_at, yv.published_at, 1 as priority
             FROM youtube_videos yv
             JOIN youtube_channels yc ON yv.channel_id = yc.id
             WHERE yv.channel_id = ANY($1::text[])
               AND yv.published_at >= NOW() - INTERVAL '90 days'
               AND yv.view_count > 100
               AND yv.duration_seconds >= 180
             ORDER BY yv.published_at DESC
             LIMIT 50)
            
            UNION ALL
            
            -- Video of the day candidates (trending recent videos)
            (SELECT yv.id, yv.view_count, yv.title, yc.title as channel_name, yv.updated_at, yv.published_at, 2 as priority
             FROM youtube_videos yv
             JOIN youtube_channels yc ON yv.channel_id = yc.id
             WHERE yv.published_at >= NOW() - INTERVAL '14 days'
               AND yv.view_count > 100
               AND yv.channel_id = ANY($1::text[])
               AND yv.thumbnail_url IS NOT NULL
               AND (yv.duration_seconds IS NULL OR yv.duration_seconds > 60)
             ORDER BY 
               CASE 
                 WHEN yv.published_at >= (NOW() AT TIME ZONE 'America/Chicago')::date THEN yv.view_count * 1000
                 WHEN yv.published_at >= NOW() - INTERVAL '24 hours' THEN yv.view_count * 100
                 WHEN yv.published_at >= NOW() - INTERVAL '48 hours' THEN yv.view_count * 10
                 ELSE yv.view_count
               END DESC
             LIMIT 20)
          )
          SELECT id, view_count, title, channel_name, MIN(priority) as priority
          FROM user_facing_videos
          WHERE (updated_at <= NOW() - INTERVAL '10 minutes'  -- Update every 10 min for displayed videos
                 OR published_at >= NOW() - INTERVAL '12 hours')  -- Fresh uploads need frequent updates
          GROUP BY id, view_count, title, channel_name
          ORDER BY MIN(priority), view_count DESC
          LIMIT 70
        `,a=(await e.query(t,[u.mN])).rows.map(e=>e.id);if(0===a.length)return void console.log("No displayed videos need view count updates");console.log(`Updating view counts for ${a.length} user-facing videos`);let o=await l.T.updateVideoBatch(a);await c.n.recordUsage("video_update",Math.ceil(a.length/50)),console.log(`View count update: ${o} displayed videos updated`)}finally{e.release()}}catch(e){console.error("View count update failed:",e),e instanceof Error&&e.message.includes("quota")?console.log("Quota exhausted, will retry next cycle"):console.error("Unexpected error in view count update:",e)}}async performCollectTodayVideos(){console.log("Collecting today videos...",new Date().toISOString());try{let e=await h.i.collectTodayVideos();console.log(`Today videos collection completed: ${e.videos_collected||0} videos collected`);let t=await h.i.getVideoOfTheDay();if(t.has_ai_analysis)console.log("Video of the day already has AI analysis");else{console.log(`Generating transcript summary for video of the day: "${t.title}" (ID: ${t.video_id})`);try{let e=await h.i.generateTranscriptSummary(t.video_id);console.log("Transcript summary generation completed:",e.summary?"Summary generated":"No summary",e.audioUrl?"Audio generated":"No audio")}catch(e){console.error("Failed to generate transcript summary:",e)}}}catch(e){console.error("Collect today videos failed:",e)}}async performMaintenanceUpdate(){console.log("Maintenance update for older popular videos...",new Date().toISOString());try{if(!await c.n.canPerformOperation("videoList"))return void console.log("Quota limit reached, skipping maintenance update");let e=await r.A.connect();try{let t=`
          SELECT yv.id, yv.title, yc.title as channel_name, yv.view_count, yv.updated_at
          FROM youtube_videos yv
          JOIN youtube_channels yc ON yv.channel_id = yc.id
          WHERE yv.channel_id = ANY($1::text[])
            AND yv.published_at < NOW() - INTERVAL '90 days'  -- Older than regular updates
            AND yv.view_count > 500000  -- Popular videos only
            AND yv.updated_at < NOW() - INTERVAL '7 days'  -- Haven't been updated in a week
          ORDER BY yv.view_count DESC
          LIMIT 100
        `,a=(await e.query(t,[u.mN])).rows.map(e=>e.id);if(0===a.length)return void console.log("No older popular videos need maintenance updates");console.log(`Maintenance updating ${a.length} older popular videos`);let o=0;for(let e=0;e<a.length;e+=50){let t=a.slice(e,e+50);if(!await c.n.canPerformOperation("videoList")){console.log("Quota limit reached during maintenance update");break}try{let i=await l.T.updateVideoBatch(t);o+=i,await c.n.recordUsage("video_update",1),console.log(`Maintenance batch ${Math.floor(e/50)+1}: Updated ${i} videos`),e+50<a.length&&await new Promise(e=>setTimeout(e,1e3))}catch(t){console.error(`Maintenance batch error for videos ${e}-${e+50}:`,t)}}console.log(`Maintenance update completed: ${o} older popular videos updated`)}finally{e.release()}}catch(e){console.error("Maintenance update failed:",e)}}async performBatchVideoUpdate(){console.log("Batch video update...",new Date().toISOString());try{let e=Date.now(),t=await c.n.getTodayUsage(),a=1e4-t.units_used;if(a<50)return void console.log("Insufficient quota for batch update");let o=await r.A.connect();try{let t=(await o.query(`
          WITH video_priority AS (
            SELECT yv.id, yv.title, yv.view_count, yc.title as channel_name,
              CASE 
                -- Highest priority: Videos from whitelisted creators (shown in curated API)
                WHEN yv.channel_id = ANY($2::text[]) 
                     AND yv.published_at >= NOW() - INTERVAL '90 days'
                     AND yv.view_count > 100
                     AND yv.duration_seconds >= 180 THEN 1
                -- Medium priority: Recent trending candidates (video of the day)
                WHEN yv.published_at >= NOW() - INTERVAL '14 days'
                     AND yv.view_count > 100 THEN 2
                -- Lower priority: Other recent videos
                WHEN yv.published_at >= NOW() - INTERVAL '7 days' THEN 3
                -- Lowest priority: Popular older videos
                WHEN yv.view_count > 50000 THEN 4
                ELSE 5
              END as priority
            FROM youtube_videos yv
            JOIN youtube_channels yc ON yv.channel_id = yc.id
            WHERE yv.updated_at < NOW() - INTERVAL '1 hour'  -- More frequent updates
          )
          SELECT id, title, view_count, channel_name
          FROM video_priority
          ORDER BY priority, view_count DESC
          LIMIT $1
        `,[Math.min(30*a,1500),u.mN])).rows.map(e=>e.id);if(0===t.length)return void console.log("No videos need batch updating");console.log(`Batch updating ${t.length} videos for fresh view counts...`);let i=0;for(let e=0;e<t.length;e+=50){let a=t.slice(e,e+50);if(!await c.n.canPerformOperation("videoList")){console.log("Quota limit reached during batch update");break}try{let o=await l.T.updateVideoBatch(a);i+=o,await c.n.recordUsage("video_update",1),console.log(`Batch ${Math.floor(e/50)+1}: Updated ${o} videos`),e+50<t.length&&await new Promise(e=>setTimeout(e,200))}catch(t){console.error(`Batch update error for videos ${e}-${e+50}:`,t)}}let s=Date.now()-e;console.log(`Batch update completed: ${i} videos updated in ${(s/1e3).toFixed(1)}s`)}finally{o.release()}}catch(e){console.error("Batch video update failed:",e),e instanceof Error&&e.message.includes("quota")?console.log("Quota exhausted for batch update, will retry next cycle"):console.error("Unexpected error in batch video update:",e)}}async performQualityScoring(){console.log("Quality scoring update...",new Date().toISOString());try{let e=Date.now(),t=await d.T.updateQualityScores(200),a=Date.now()-e,o={videos_scored:t,duration_ms:a,timestamp:new Date().toISOString()};console.log("Quality scoring completed:",o),t>0&&n.I.broadcastStatsUpdate({message:"Content quality scoring completed",...o})}catch(e){console.error("Quality scoring failed:",e),e instanceof Error&&e.message.includes("quota")?console.log("Quota exhausted for quality scoring, will retry next cycle"):console.error("Unexpected error in quality scoring:",e)}}getStatus(){return{isRunning:this.isRunning,activeTasks:Array.from(this.tasks.keys()),tasksCount:this.tasks.size,lastHeartbeat:new Date(this.lastHeartbeat).toISOString(),heartbeatActive:null!==this.heartbeatInterval}}constructor(){this.tasks=new Map,this.isRunning=!1,this.heartbeatInterval=null,this.lastHeartbeat=Date.now()}}let p=new g;o()}catch(e){o(e)}})},61107:(e,t,a)=>{"use strict";a.d(t,{i:()=>s});let o="http://localhost:3000";class i{async collectTodayVideos(){let e=await fetch(`${o}/api/collect-today-videos`,{method:"POST",headers:{"Content-Type":"application/json"}});if(!e.ok)throw Error(`Failed to collect today videos: ${e.status} ${e.statusText}`);return e.json()}async getVideoOfTheDay(){let e=await fetch(`${o}/api/video-of-the-day`);if(!e.ok)throw Error(`Failed to get video of the day: ${e.status} ${e.statusText}`);return e.json()}async generateTranscriptSummary(e){let t=await fetch(`${o}/api/generate-transcript-summary/${e}`,{method:"POST",headers:{"Content-Type":"application/json"}});if(!t.ok)throw Error(`Failed to generate transcript summary: ${t.status} ${t.statusText}`);return t.json()}}let s=new i},66718:(e,t,a)=>{"use strict";a.d(t,{mN:()=>i,zd:()=>s});let o=["good good","bob does sports","grant horvat","bryan bros","foreplay","dude perfect","gm golf","micah morris golf","garrett clark","tig","fat perez","the jet","cold cuts","bubbie","steve","matt","micah","brad dalke","lanto griffin","erik anders lang","the golfers journal","no laying up","fore the people","rick shiels","peter finch","mark crossfield","me and my golf","athletic motion golf","dan whittaker golf","golf monthly","golf.com","dan hendriksen","chris ryan golf","scratch golf academy","golf sidekick","james robinson golf","golf distillery","danny maude","alex elliott golf","golf swing simplified","top speed golf","golf tips magazine","rotary swing","eric cogorno","eric cogorno golf","cogorno golf","matt fryer golf","matt fryer","alex etches golf","alex etches","golf channel","the scratch golf show","scratch golf show","golf wrx","test golf","golf equipment guru","golf gurus","clay ballard","txg","golf monthly gear","2nd swing golf","fairway jockey","golf monthly reviews","fore fore","golf boys","golf life","scramble podcast","barstool golf","golf unfiltered","bad golf","golf beast","golf it","golf gods","golf time","ron chopper golf","ron chopper","luke kwon golf","luke kwon","the lads","phil mickelson","hyflyers","micah morris","tommy fleetwood","sean walsh","jake hutt golf","jake hutt","mytpi","titleist","taylormade","taylor made","garrett hilbert","tyler toney","brad dalke golf","stephen castaneda golf","ben polland golf","garrett johnston golf","amateur golf","golf with aimee","golf with aim","golf with friends","golf adventures","coffee and golf","golf diary","golf tales","big wedge golf","big wedge","padraig harrington","mrshortgame golf","mrshortgame","mr short game","jna golf","jna","bryan bros tv","josh mayer","golf girl games","girl golf games","golf life"],i=["UCfi-mPMOmche6WI-jkvnGXw","UCbY_v56iMzSGvXK79X6f4dw","UCqr4sONkmFEOPc3rfoVLEvg","UCgUueMmSpcl-aCTt5CuCKQw","UCJcc1x6emfrQquiV8Oe_pug","UCsazhBmAVDUL_WYcARQEFQA","UC3jFoA7_6BTV90hsRSVHoaw","UCfdYeBYjouhibG64ep_m4Vw","UCjchle1bmH0acutqK15_XSA","UCdCxaD8rWfAj12rloIYS6jQ","UCB0NRdlQ6fBYQX8W8bQyoDA","UCyy8ULLDGSm16_EkXdIt4Gw","UClJO9jvaU5mvNuP-XTbhHGw","UCFHZHhZaH7Rc_FOMIzUziJA","UCFoez1Xjc90CsHvCzqKnLcw","UCCxF55adGXOscJ3L8qdKnrQ","UCZelGnfKLXic4gDP63dIRxw","UCaeGjmOiTxekbGUDPKhoU-A","UCtNpbO2MtsVY4qW23WfnxGg","UCUOqlmPAo8h4pVQ4cuRECUg","UClljAz6ZKy0XeViKsohdjqA","UCSwdmDQhAi_-ICkAvNBLEBw","UCJolpQHWLAW6cCUYGgean8w","UCuXIBwKQeH9cnLOv7w66cJg","UCXvDkP2X3aE9yrPavNMJv0A","UCamOYT0c_pSrSCu9c8CyEcg","UCrgGz4gZxWu77Nw5RXcxlRg","UCCry5X3Phfmz0UzqRNm0BPA","UCwMgdK0S57nEdN_RGaajwOQ"];function s(e,t){if(t&&i.includes(t))return!0;let a=e.toLowerCase();return o.some(e=>a.includes(e.toLowerCase()))}},76786:(e,t,a)=>{"use strict";a.d(t,{I:()=>n});var o=a(96402),i=a(81630);class s{start(e=8080){if(this.wss||this.isStarting)return void console.log("WebSocket server already running or starting");this.isStarting=!0,this.cleanup();try{this.server=(0,i.createServer)(),this.wss=new o.zu({server:this.server})}catch(e){console.error("Error creating WebSocket server:",e),this.isStarting=!1;return}this.wss.on("connection",e=>{console.log("Client connected to WebSocket"),this.clients.add(e),this.sendToClient(e,{type:"stats_update",data:{message:"Connected to StreamingRange live updates"},timestamp:new Date().toISOString()}),e.on("close",()=>{console.log("Client disconnected from WebSocket"),this.clients.delete(e)}),e.on("error",t=>{console.error("WebSocket error:",t),this.clients.delete(e)})}),this.server.on("error",t=>{"EADDRINUSE"===t.code?console.log(`Port ${e} is already in use, WebSocket server not started`):console.error("WebSocket server error:",t),this.cleanup()});try{this.server.listen(e,()=>{console.log(`WebSocket server running on port ${e}`),this.isStarting=!1})}catch(e){console.error("Failed to start WebSocket server:",e),this.cleanup()}}sendToClient(e,t){e.readyState===o.kb.OPEN&&e.send(JSON.stringify(t))}broadcast(e){console.log(`Broadcasting to ${this.clients.size} clients:`,e.type),this.clients.forEach(t=>{this.sendToClient(t,e)})}broadcastStatsUpdate(e){this.broadcast({type:"stats_update",data:e,timestamp:new Date().toISOString()})}broadcastAccelerationUpdate(e,t,a){this.broadcast({type:"acceleration_update",data:{videoId:e,acceleration:t,velocity:a},timestamp:new Date().toISOString()})}stop(){this.cleanup(),console.log("WebSocket server stopped")}cleanup(){try{this.wss&&(this.wss.close(()=>{console.log("WebSocket server closed")}),this.wss=null),this.server&&(this.server.close(()=>{console.log("HTTP server closed")}),this.server=null),this.clients.clear(),this.isStarting=!1}catch(e){console.error("Error during cleanup:",e),this.wss=null,this.server=null,this.clients.clear(),this.isStarting=!1}}constructor(){this.wss=null,this.clients=new Set,this.server=null,this.isStarting=!1}}let n=new s;process.on("SIGTERM",()=>{console.log("SIGTERM received, cleaning up WebSocket server"),n.stop()}),process.on("SIGINT",()=>{console.log("SIGINT received, cleaning up WebSocket server"),n.stop()}),process.on("exit",()=>{n.stop()})}};